import os
from datetime import datetime
import torch
from torch.utils.data import DataLoader, random_split
import torchvision.transforms as transforms
import pytorch_lightning as pl
from dataset import CustomTiffDataset, compute_min_max, MinMaxNormalize
from model.model import UNet_Transpose, UNet_Deeper
from loss import PSNRLoss
import tifffile as tiff

# Lightning Module
class UNetLightningModule(pl.LightningModule):
    def __init__(self, lf_extra, n_slices, output_size, learning_rate, input_min_val, input_max_val, gt_min_val, gt_max_val):
        super(UNetLightningModule, self).__init__()
        self.model = UNet_Deeper(lf_extra, n_slices, output_size)
        self.criterion = torch.nn.MSELoss()
        self.PSNR_loss = PSNRLoss()
        self.learning_rate = learning_rate
        self.input_min_val = input_min_val
        self.input_max_val = input_max_val
        self.gt_min_val = gt_min_val
        self.gt_max_val = gt_max_val

    def forward(self, x):
        return self.model(x)

    def configure_optimizers(self):
        return torch.optim.Adam(self.model.parameters(), lr=self.learning_rate)

    def training_step(self, batch, batch_idx):
        inputs, labels, _ = batch
        outputs = self(inputs)
        mse_loss = self.criterion(outputs, labels)
        psnr_loss = self.PSNR_loss(outputs, labels)
        total_loss = mse_loss +1e-4* psnr_loss
        self.log('train_loss', total_loss)
        self.log('train_mse_loss', mse_loss)
        self.log('train_psnr_loss', psnr_loss)
        return total_loss

    def validation_step(self, batch, batch_idx):
        inputs, labels, _ = batch
        outputs = self(inputs)
        mse_loss = self.criterion(outputs, labels)
        psnr_loss = self.PSNR_loss(outputs, labels)
        total_loss = mse_loss +1e-4* psnr_loss
        self.log('val_loss', total_loss)
        self.log('val_mse_loss', mse_loss)
        self.log('val_psnr_loss', psnr_loss)
        return total_loss

# Custom callback to save inference results every 10 epochs
class SaveInferenceCallback(pl.Callback):
    def __init__(self, sample_dir, epoch_interval=10):
        self.sample_dir = sample_dir
        self.epoch_interval = epoch_interval

    def on_validation_epoch_end(self, trainer, pl_module):
        epoch = trainer.current_epoch
        if (epoch + 1) % self.epoch_interval == 0:
            val_loader = trainer.datamodule.val_dataloader()
            pl_module.model.eval()
            with torch.no_grad():
                for idx, (inputs, labels, input_filename) in enumerate(val_loader):
                    inputs = inputs.to(pl_module.device)
                    outputs = pl_module(inputs)
                    output_filename = f"{input_filename}_epoch{epoch + 1}.tif"
                    output_path = os.path.join(self.sample_dir, output_filename)
                    os.makedirs(os.path.dirname(output_path), exist_ok=True)
                    image = outputs.cpu().numpy().squeeze()
                    tiff.imwrite(output_path, image, compression="deflate")
            pl_module.model.train()

# Data Module
class TiffDataModule(pl.LightningDataModule):
    def __init__(self, input_dir, gt_dir, batch_size, input_transform, gt_transform):
        super().__init__()
        self.input_dir = input_dir
        self.gt_dir = gt_dir
        self.batch_size = batch_size
        self.input_transform = input_transform
        self.gt_transform = gt_transform

    def setup(self, stage=None):
        dataset = CustomTiffDataset(input_dir=self.input_dir, gt_dir=self.gt_dir, input_transform=self.input_transform, gt_transform=self.gt_transform)
        total_size = len(dataset)
        test_size = int(0.1 * total_size)
        train_size = total_size - test_size
        self.train_dataset, self.val_dataset = random_split(dataset, [train_size, test_size])

    def train_dataloader(self):
        return DataLoader(self.train_dataset, batch_size=self.batch_size, shuffle=True, num_workers=7)

    def val_dataloader(self):
        return DataLoader(self.val_dataset, batch_size=self.batch_size, shuffle=False, num_workers=7)

# Main script
if __name__ == "__main__":
    # Parameters and paths
    input_dir = '/gpfs/home/LifeSci/wenlab/hefengcs/VCD_dataset/input900'
    gt_dir = '/gpfs/home/LifeSci/wenlab/hefengcs/VCD_dataset/gt900'
    current_time = datetime.now().strftime('%Y%m%d-%H%M%S')
    tag = 'Unet_deeper_PSNR_MSE_0722'
    label = tag + str(current_time)
    main_dir = '/gpfs/home/LifeSci/wenlab/hefengcs/VCD_torch_gnode05/'
    ckpt_dir = os.path.join(main_dir, 'ckpt', label)
    sample_dir = os.path.join(main_dir, 'sample', label)
    log_dir = os.path.join(main_dir, 'logs', label)
    os.makedirs(log_dir, exist_ok=True)
    os.makedirs(sample_dir, exist_ok=True)
    os.makedirs(ckpt_dir, exist_ok=True)

    bz = 1
    Ir = 1 * 1e-4
    lf_extra = 27  # Number of input channels
    n_slices = 300  # Number of output slices
    output_size = (600, 600)  # Output size

    # Initial transform for computing min and max values
    initial_transform = transforms.Compose([transforms.ToTensor()])
    dataset = CustomTiffDataset(input_dir=input_dir, gt_dir=gt_dir, input_transform=initial_transform)
    dataloader = DataLoader(dataset, batch_size=bz, shuffle=True)
    input_min_val, input_max_val, gt_min_val, gt_max_val = compute_min_max(dataloader)

    # Data transformations
    input_transform = transforms.Compose([
        transforms.ToTensor(),
        MinMaxNormalize(input_min_val, input_max_val)
    ])
    gt_transform = transforms.Compose([
        transforms.ToTensor(),
        MinMaxNormalize(gt_min_val, gt_max_val)
    ])

    # Data module
    data_module = TiffDataModule(input_dir, gt_dir, bz, input_transform, gt_transform)

    # Model module
    model_module = UNetLightningModule(lf_extra, n_slices, output_size, Ir, input_min_val, input_max_val, gt_min_val, gt_max_val)

    # Callbacks
    checkpoint_callback = pl.callbacks.ModelCheckpoint(
        dirpath=ckpt_dir,
        save_top_k=1,
        monitor='val_loss',
        mode='min',
        filename='{epoch}-{val_loss:.2f}'
    )
    lr_monitor = pl.callbacks.LearningRateMonitor(logging_interval='epoch')
    save_inference_callback = SaveInferenceCallback(sample_dir, epoch_interval=10)

    # Logger
    logger = pl.loggers.TensorBoardLogger(log_dir)

    # Trainer
    trainer = pl.Trainer(
        max_epochs=250,
        devices=8,
        accelerator='gpu',
        strategy='ddp',
        callbacks=[checkpoint_callback, lr_monitor, save_inference_callback],
        logger=logger
    )

    # Train the model
    trainer.fit(model_module, datamodule=data_module)
