import os

import numpy as np
os.environ["CUDA_VISIBLE_DEVICES"] = "0,3,4,5"
#os.environ["CUDA_VISIBLE_DEVICES"] = "2,3,4,7"
import sys
from datetime import datetime
import torch
torch.set_float32_matmul_precision('high')
from torch.utils.data import DataLoader, random_split
import torchvision.transforms as transforms
import pytorch_lightning as pl
from dataset import CustomTiffDataset, compute_min_max, MinMaxNormalize,CustomTiffDataset_double_gt,compute_min_max_double_gt
current_dir = os.path.dirname(__file__)
# 获取src目录的路径
src_dir = os.path.abspath(os.path.join(current_dir, '..'))

# 将src目录添加到sys.path
sys.path.append(src_dir)
from utils.head import CombinedModel_deeper_mutistage
# 导入模型
from model.model import UNet_Transpose, UNet_Deeper
from loss import SSIMLoss
import tifffile as tiff
from pytorch_lightning.profilers import AdvancedProfiler
# PSNR Loss function
class PSNRLoss(torch.nn.Module):
    def __init__(self, max_val=1.0):
        super(PSNRLoss, self).__init__()
        self.max_val = max_val

    def forward(self, x, y):
        mse = torch.mean((x - y) ** 2)
        psnr = 20 * torch.log10(self.max_val / torch.sqrt(mse))
        return -psnr  # Note: We return negative PSNR for minimization

# Lightning Module
class UNetLightningModule(pl.LightningModule):
    def __init__(self, lf_extra, n_slices, output_size, learning_rate, input_min_val, input_max_val, gt_min_val, gt_max_val):
        super(UNetLightningModule, self).__init__()
        #self.model = UNet_Deeper(lf_extra, n_slices, output_size)

        #self.register_buffer('PSF_fft', PSF_fft)

        self.model = CombinedModel_deeper_mutistage()

        self.criterion = PSNRLoss()
        self.SSIM_loss = SSIMLoss(size_average=True)
        self.mse_loss_fn = torch.nn.MSELoss()
        self.learning_rate = learning_rate
        self.input_min_val = input_min_val
        self.input_max_val = input_max_val
        self.gt_min_val = gt_min_val
        self.gt_max_val = gt_max_val

    # def setup(self, stage=None):
    #     # 确保 PSF_fft 移动到与模型相同的设备上
    #     if self.PSF_fft.device != self.device:
    #         self.PSF_fft = self.PSF_fft.to(self.device)
    def forward(self, x):
        return self.model(x)
    # def on_fit_start(self):
    #     # 在模型开始训练时，将 PSF_fft 转移到当前模型设备上，只需执行一次
    #     self.PSF_fft = self.PSF_fft.to(self.device)
    def configure_optimizers(self):
        optimizer = torch.optim.Adam(self.model.parameters(), lr=self.learning_rate)
        scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', factor=0.5, patience=10, verbose=True)
        return {
            'optimizer': optimizer,
            'lr_scheduler': {
                'scheduler': scheduler,
                'monitor': 'val_loss'
            }
        }

    def training_step(self, batch, batch_idx):
        inputs, label_recon, label_FP,_ = batch
        label_FP =label_FP.permute(0,2,3,1)
        outputs,bp = self(inputs)
        loss_recon = self.criterion(outputs, label_recon)  # shape: (1, 300, 600, 600)
        loss_forward = self.criterion(bp, label_FP)  # shape: (1, 1, 2048, 10248)

        # 对两个损失都求平均，使其成为标量
        loss_recon_mean = loss_recon.mean()
        loss_forward_mean = loss_forward.mean()

        # 将两个标量相加
        loss = loss_recon_mean + loss_forward_mean

        #记录图像bp，维度是1,2048,2048,1
        bp = bp.squeeze(0)  # 将形状从 (1, 2048, 2048, 1) 转为 (2048, 2048, 1)
        label_FP = label_FP.squeeze(0)

        self.logger.experiment.add_image('bp_image/train', bp[:,:,13:14], batch_idx, dataformats='HWC')
        self.logger.experiment.add_image('label_FP_image/train', label_FP[:,:,13:14], batch_idx, dataformats='HWc')
        self.logger.experiment.add_image('input_image/train', inputs[:, -1,:,:]*self.input_max_val, batch_idx, dataformats='CHW')
        self.log('train_loss/train', loss)
        self.log('train_loss_recon_mean/train', loss_recon_mean)
        self.log('train_loss_forward_mean/train', loss_forward_mean)
        return loss

    def validation_step(self, batch, batch_idx):
        inputs, label_recon, label_FP,_ = batch
        outputs, bp = self(inputs)
        label_FP =label_FP.permute(0,2,3,1)
        loss_recon = self.criterion(outputs, label_recon)  # shape: (1, 300, 600, 600)
        loss_forward = self.criterion(bp, label_FP)  # shape: (1, 1, 2048, 10248)

        # 对两个损失都求平均，使其成为标量
        loss_recon_mean = loss_recon.mean()
        loss_forward_mean = loss_forward.mean()

        # 将两个标量相加
        val_total_psnr_loss = loss_recon_mean + loss_forward_mean


        mse_loss = self.mse_loss_fn(outputs, label_recon)
        ssim_loss = self.SSIM_loss(outputs, label_recon)
        psnr_loss = self.criterion(outputs, label_recon)

        #可视化
        self.log('validation_mse_loss /validation', mse_loss )
        self.log('validation_ssim_loss/validation', ssim_loss)
        self.log('validation_psnr_loss/validation', psnr_loss)
        val_loss =mse_loss




        # 记录图像bp，维度是1,2048,2048,1
        bp = bp.squeeze(0)  # 将形状从 (1, 2048, 2048, 1) 转为 (2048, 2048, 1)
        label_FP = label_FP.squeeze(0)
        self.logger.experiment.add_image('label_FP_image/validation', label_FP[:,:,13:14], batch_idx, dataformats='HWC')
        self.logger.experiment.add_image('bp_image/validation', bp[:,:,13:14], batch_idx, dataformats='HWC')
        self.log('validation_total_psnr_loss/validation', val_total_psnr_loss)
        self.log('validation_loss_recon_mean/validation', loss_recon_mean)
        self.log('validation_loss_forward_mean/validation', loss_forward_mean)
        self.log('val_loss', val_loss)
        return val_loss

# Custom callback to save inference results every 10 epochs
class SaveInferenceCallback(pl.Callback):
    def __init__(self, sample_dir,  gt1_max_val, epoch_interval=20,):
        self.sample_dir = sample_dir
        self.epoch_interval = epoch_interval
        self.gt1_max_val =gt1_max_val
    def on_validation_epoch_end(self, trainer, pl_module):
        epoch = trainer.current_epoch
        if (epoch + 1) % self.epoch_interval == 0:
            val_loader = trainer.datamodule.val_dataloader()
            pl_module.model.eval()
            with torch.no_grad():
                for idx, (inputs, gt_image1, gt_image2, input_filename) in enumerate(val_loader):
                    inputs = inputs.to(pl_module.device)
                    outputs,_ = pl_module(inputs)
                    #input_filename = f"input_{idx}.tif"
                    output_filename = f"{input_filename}_epoch{epoch + 1}.tif"
                    output_path = os.path.join(self.sample_dir, output_filename)
                    os.makedirs(os.path.dirname(output_path), exist_ok=True)
                    image = outputs.cpu().numpy().squeeze()
                    tiff.imwrite(output_path, image*self.gt1_max_val, compression="deflate")
            pl_module.model.train()

# Data Module
class TiffDataModule(pl.LightningDataModule):
    def __init__(self, input_dir, gt_dir1,gt_dir2, batch_size, input_transform, gt_transform,gt2_transform):
        super().__init__()
        self.input_dir = input_dir
        self.gt_dir1 = gt_dir1
        self.gt_dir2 = gt_dir2
        self.batch_size = batch_size
        self.input_transform = input_transform
        self.gt_transform = gt_transform
        self.gt2_transform = gt2_transform

    def setup(self, stage=None):
        dataset = CustomTiffDataset_double_gt(input_dir=self.input_dir, gt_dir1=self.gt_dir1,gt_dir2=self.gt_dir2, input_transform=self.input_transform, gt_transform=self.gt_transform,gt2_transform=self.gt2_transform)
        total_size = len(dataset)
        test_size = int(0.1 * total_size)
        train_size = total_size - test_size
        self.train_dataset, self.val_dataset = random_split(dataset, [train_size, test_size])

    def train_dataloader(self):
        return DataLoader(self.train_dataset, batch_size=self.batch_size, shuffle=True, num_workers=8,pin_memory=True)

    def val_dataloader(self):
        return DataLoader(self.val_dataset, batch_size=self.batch_size, shuffle=False, num_workers=8, pin_memory=True)

# Main script
if __name__ == "__main__":
    # Parameters and paths
    input_dir = '/home/LifeSci/wenlab/hefengcs/VCD_dataset/input1500_location'
    gt_dir1 = '/gpfs/home/LifeSci/wenlab/hefengcs/VCD_dataset/gt_RLD60_1500'
    gt_dir2 = '/gpfs/home/LifeSci/wenlab/hefengcs/VCD_dataset/gt_RLD60_1500_conv_crop'


    #checkpoint_path = '/gpfs/home/LifeSci/wenlab/hefengcs/VCD_torch_gnode05/ckpt/NAFNet_mutiRLD_pure_PSNR_RLD60_fish1_1500_091120240911-161524/save/epoch=46-val_loss=0.0000007939.ckpt'
    current_time = datetime.now().strftime('%Y%m%d-%H%M%S')
    tag = 'NAFNet_mutiRLD__PSNR_RLD60_fish1_1500_0917_normalize_no_pretrained'
    label = tag + str(current_time)
    main_dir = '/gpfs/home/LifeSci/wenlab/hefengcs/VCD_torch_gnode05/'
    ckpt_dir = os.path.join(main_dir, 'ckpt', label)
    sample_dir = os.path.join(main_dir, 'sample', label)
    log_dir = os.path.join(main_dir, 'logs', label)
    os.makedirs(log_dir, exist_ok=True)
    os.makedirs(sample_dir, exist_ok=True)
    os.makedirs(ckpt_dir, exist_ok=True)

    bz = 1
    Ir = 1 * 1e-4
    lf_extra = 27  # Number of input channels
    n_slices = 300  # Number of output slices
    output_size = (600, 600)  # Output size

    # Initial transform for computing min and max values
    initial_transform = transforms.Compose([transforms.ToTensor()])
    dataset = CustomTiffDataset_double_gt(input_dir=input_dir, gt_dir1=gt_dir1,gt_dir2=gt_dir2, input_transform=initial_transform)
    dataloader = DataLoader(dataset, batch_size=bz, shuffle=True,num_workers=64 )
    input_min_val, input_max_val, gt1_min_val, gt1_max_val, gt2_min_val, gt2_max_val = compute_min_max_double_gt(dataloader)

    # Data transformations
    input_transform = transforms.Compose([
        transforms.ToTensor(),
        MinMaxNormalize(input_min_val, input_max_val)
    ])
    gt1_transform = transforms.Compose([
        transforms.ToTensor(),
        MinMaxNormalize(gt1_min_val, gt1_max_val)
    ])

    gt2_transform = transforms.Compose([
        transforms.ToTensor(),
        MinMaxNormalize(gt2_min_val, gt2_max_val)
    ])



    # Data module
    data_module = TiffDataModule(input_dir, gt_dir1,gt_dir2, bz, input_transform, gt1_transform,gt2_transform)
    #PSF_fft = torch.load('/gpfs/home/LifeSci/wenlab/hefengcs/VCD_torch_gnode05/data/PSF_fft.pt')
    #checkpoint = torch.load(checkpoint_path)
    #Model module
    model_module = UNetLightningModule(lf_extra, n_slices, output_size, Ir, input_min_val, input_max_val, gt1_min_val, gt1_max_val)
    # model_state_dict = model_module.state_dict()

    # 对比检查点的 state_dict 和当前模型的 state_dict，只加载匹配的部分
    # checkpoint_state_dict = {k: v for k, v in checkpoint['state_dict'].items() if
    #                          k in model_state_dict and model_state_dict[k].shape == v.shape}
    #
    # # 更新模型参数
    # model_state_dict.update(checkpoint_state_dict)
    # model_module.load_state_dict(model_state_dict)
    # Callbacks
    checkpoint_callback = pl.callbacks.ModelCheckpoint(
        dirpath=ckpt_dir,
        save_top_k=1,
        monitor='val_loss',
        mode='min',
        filename='{epoch}-{val_loss:.10f}'
    )
    lr_monitor = pl.callbacks.LearningRateMonitor(logging_interval='epoch')
    save_inference_callback = SaveInferenceCallback(sample_dir, epoch_interval=10,gt1_max_val=gt1_max_val)

    # Logger
    logger = pl.loggers.TensorBoardLogger(log_dir)

    # Trainer
    trainer = pl.Trainer(
        max_epochs=250,
        devices=4,
        #devices=1,
        accelerator='gpu',
        strategy='ddp',
        callbacks=[checkpoint_callback, lr_monitor, save_inference_callback],
        logger=logger,
        log_every_n_steps=100,
        num_sanity_val_steps=0,
        #precision=16,
    )

    # Train the model
    trainer.fit(model_module, datamodule=data_module)
