import os
os.environ["CUDA_VISIBLE_DEVICES"] = "2,4,6,7"
import numpy as np

# os.environ["CUDA_VISIBLE_DEVICES"] = "6,7"

import sys
from datetime import datetime
import torch

from torch.utils.data import DataLoader, random_split
torch.set_float32_matmul_precision('high')
import torchvision.transforms as transforms
import pytorch_lightning as pl
seed = 42
pl.seed_everything(seed)
from dataset import CustomTiffDataset, compute_min_max, MinMaxNormalize,CustomTiffDataset_FP, SynchronizedTransform, ValTransform, compute_percentiles,minmax_percentile_normalize,CustomTiffDatasetSinglePercentile
current_dir = os.path.dirname(__file__)
# 获取src目录的路径
src_dir = os.path.abspath(os.path.join(current_dir, '..'))
import h5py
# 将src目录添加到sys.path
sys.path.append(src_dir)
from utils.head import Swin_Transformer_Recon_fusion
# 导入模型
from loss import  consistency_loss, consistency_loss_log, compute_projection_loss, edges_loss, SSIMLoss, multi_scale_mse,PyramidPoolingLoss
from loss import ms_ssim
import tifffile as tiff
import time
import torch.autograd.profiler as profiler
# PSNR Loss function
import torch.nn as nn
import torchvision.transforms.functional as F
from PIL import Image
import albumentations as A
import numpy as np
import cv2
from albumentations.pytorch import ToTensorV2
from data_aug import RandomRotation, ToTensor, Compose, RandomHorizontalFlip, RandomVerticalFlip, RandomGaussianNoise, \
    RandomGaussianBlur, RandomBrightness, RandomContrast


class PSNRLoss(torch.nn.Module):
    def __init__(self, max_val=1.0):
        super(PSNRLoss, self).__init__()
        self.max_val = max_val

    def forward(self, x, y):
        mse = torch.mean((x - y) ** 2)
        psnr = 20 * torch.log10(self.max_val / torch.sqrt(mse))
        return -psnr  # Note: We return negative PSNR for minimization

# Lightning Module
class UNetLightningModule(pl.LightningModule):
    def __init__(self, learning_rate):
        super(UNetLightningModule, self).__init__()
        self.model = Swin_Transformer_Recon_fusion()
        self.criterion = PSNRLoss()
        self.SSIM_loss = ms_ssim
        #self.consistency_loss_fn = consistency_loss
        self.mse_loss_fn = torch.nn.MSELoss()
        self.MIP_loss_fn = compute_projection_loss
        self.learning_rate = learning_rate
        self.multi_scale_mse =PyramidPoolingLoss()
        #self.noise_regularization = noise_regularization
        # self.input_min_val = input_min_val
        # self.input_max_val = input_max_val
        # self.gt_min_val = gt_min_val
        # self.gt_max_val = gt_max_val
        #h5_path = '/gpfs/home/LifeSci/wenlab/hefengcs/VCD_torch_gnode05/RLD_test/PSF_G.mat'
        self.edge_loss = edges_loss
        #self.PSF = self.read_hdf5(h5_path)
        self.relu = nn.ReLU()


    def forward(self, x):
        x = self.model(x)
        x = self.relu(x)
        return x

    def configure_optimizers(self):
        optimizer = torch.optim.Adam(self.model.parameters(), lr=self.learning_rate)
        scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', factor=0.5, patience=3, verbose=True)
        return {
            'optimizer': optimizer,
            'lr_scheduler': {
                'scheduler': scheduler,
                'monitor': 'val_loss'
            }
        }

    def training_step(self, batch, batch_idx):
        inputs, labels, img_name, p_low, p_high = batch

        # 模型前向传播，使用混合精度


        outputs = self(inputs)
        psnr_loss = self.criterion(outputs, labels)

        # self.logger.experiment.add_image('aug_inputs/train', inputs[:,-1,:,:], batch_idx, dataformats='CHW')
        # self.logger.experiment.add_image('aug_label/train', labels[0,150:151:,:]*2, batch_idx, dataformats='CHW')
        high_value_mask = (labels > 5e-3).float()
        high_value_loss = (high_value_mask * (outputs - labels) ** 2).mean()

        # consistency_loss_log 使用全精度
        edges_loss_value = self.edge_loss(outputs, labels)
        #consistency_loss_value = consistency_loss_log(outputs, labels, self.PSF_fft, self.logger, self.global_step)
        MIP_loss_value = self.MIP_loss_fn(outputs, labels)
        ssim_loss_value = self.SSIM_loss(outputs, labels)
        multi_scale_mse_value = self.multi_scale_mse(outputs, labels)
        snr_value = self.noise_regularization(outputs, labels)
        # 计算总损失
        #total_loss = (psnr_loss /44) #+(MIP_loss_value/1e-3)
        train_loss = (psnr_loss/43)+(1-ssim_loss_value/0.95) +(edges_loss_value/1e-4)  +(MIP_loss_value/1e-3)+(multi_scale_mse_value/1e-5)+(high_value_loss/1e-4)+snr_value/49
        # 记录损失到 TensorBoard
        self.log('train_loss', train_loss, sync_dist=True)
        self.log('train_high_value_loss', high_value_loss, sync_dist=True)
        self.log('train_edges_loss', edges_loss_value, sync_dist=True)
        self.log('snr_loss', snr_value, sync_dist=True)
        self.log('train_ssim_loss', ssim_loss_value , sync_dist=True)
        self.log('train_psnr_loss', psnr_loss, sync_dist=True)
        self.log('train_multi_scale_mse_loss', multi_scale_mse_value, sync_dist=True)
        self.log('train_MIP_loss_value', MIP_loss_value, sync_dist=True)
        return train_loss

    def validation_step(self, batch, batch_idx):
        inputs, labels, img_name, p_low, p_high = batch

        # 模型前向传播，使用混合精度

        outputs = self(inputs)
        mse_loss = self.mse_loss_fn(outputs, labels)
        psnr_loss = self.criterion(outputs, labels)
        ssim_loss_value = self.SSIM_loss(outputs, labels)
        edges_loss_value = self.edge_loss(outputs, labels)
        MIP_loss_value = self.MIP_loss_fn(outputs, labels)
        # consistency_loss_log 使用全精度
        high_value_mask = (labels > 5e-3).float()
        high_value_loss = (high_value_mask * (outputs - labels) ** 2).mean()
        snr_value = self.noise_regularization(outputs, labels)
        #consistency_loss_value = consistency_loss_log(outputs, labels, self.PSF_fft, self.logger, self.global_step)

        multi_scale_mse_value = self.multi_scale_mse(outputs, labels)
        # 计算总损失
        #total_loss = (psnr_loss /44) #+(MIP_loss_value/1e-3)
        val_loss = (psnr_loss/43)+(1-ssim_loss_value/0.95) +(edges_loss_value/1e-4)  +(MIP_loss_value/1e-3)+(multi_scale_mse_value/1e-5)+(high_value_loss/1e-4)+snr_value/49

        # 记录损失到 TensorBoard
        self.log('val_loss', val_loss, sync_dist=True)
        self.log('val_mse_loss', mse_loss, sync_dist=True)
        self.log('snr_loss', snr_value, sync_dist=True)
        self.log('val_high_value_loss', high_value_loss, sync_dist=True)
        self.log('val_ssim_loss', ssim_loss_value, sync_dist=True)
        #self.log('val_consistency_loss', consistency_loss_value, sync_dist=True)
        self.log('val_psnr_loss', psnr_loss, sync_dist=True)

        return val_loss

# Custom callback to save inference results every 10 epochs
class SaveInferenceCallback(pl.Callback):
    def __init__(self, sample_dir,epoch_interval=20,):
        self.sample_dir = sample_dir
        self.epoch_interval = epoch_interval
        # self.low = low
        # self.high =high
    def on_validation_epoch_end(self, trainer, pl_module):
        epoch = trainer.current_epoch
        if (epoch) % self.epoch_interval == 1:
            val_loader = trainer.datamodule.val_dataloader()
            pl_module.model.eval()
            with torch.no_grad():
                for idx, (inputs, labels, input_filename, low, high) in enumerate(val_loader):
                    inputs = inputs.to(pl_module.device)
                    outputs = pl_module(inputs)

                    output_filename = f"{input_filename}_epoch{epoch + 1}.tif"
                    output_path = os.path.join(self.sample_dir, output_filename)
                    os.makedirs(os.path.dirname(output_path), exist_ok=True)
                    #low, high转成numpy,从tensor


                    low = low.cpu().numpy().astype(np.float32)
                    high = high.cpu().numpy().astype(np.float32)
                    image = outputs.cpu().numpy().squeeze()
                    image = image * (high - low) + low

                    tiff.imwrite(output_path, image)
                pl_module.model.train()

# Data Module
class TiffDataModule(pl.LightningDataModule):
    def __init__(self, train_list,val_list, batch_size, train_input_transform, train_gt_transform,train_transform, val_input_transform, val_gt_transform):
        super().__init__()
        # self.train_input_dir = train_input_dir
        # self.train_gt_dir = train_gt_dir
        # self.val_input = val_input_dir
        # self.val_gt = val_gt_dir
        self.batch_size = batch_size
        self.train_input_transform = train_input_transform
        self.train_gt_transform = train_gt_transform
        self.val_input_transform = val_input_transform
        self.val_gt_transform = val_gt_transform
        self.train_list = train_list
        self.val_list =val_list
        self.train_transform = train_transform
    def setup(self, stage=None):
        # dataset = CustomTiffDataset(input_dir=self.input_dir, gt_dir=self.gt_dir, input_transform=self.train_input_transform, gt_transform=self.train_gt_transform)
        # total_size = len(dataset)
        # test_size = int(0.1 * total_size)
        # train_size = total_size - test_size
        # self.train_dataset, self.val_dataset = random_split(dataset, [train_size, test_size])
        #
        # # Validation dataset should use non-augmented transformations
        # self.val_dataset.dataset.input_transform = self.val_input_transform
        # self.val_dataset.dataset.gt_transform = self.val_gt_transform
        #创建训练集
        #创建训练集

        self.train_dataset = CustomTiffDatasetSinglePercentile( txt_file=self.train_list,train_transform=self.train_transform,input_transform=self.train_input_transform, gt_transform=self.train_gt_transform)
        #创建验证集
        self.val_dataset = CustomTiffDatasetSinglePercentile( txt_file=self.val_list,input_transform=self.val_input_transform, gt_transform=self.val_gt_transform)


    def train_dataloader(self):
        return DataLoader(self.train_dataset, batch_size=self.batch_size, shuffle=True, num_workers=2,pin_memory=True,persistent_workers=True)
        #2:39,10
        #4：40, 18
    def val_dataloader(self):
        return DataLoader(self.val_dataset, batch_size=self.batch_size, shuffle=False,  num_workers=2,pin_memory=True,persistent_workers=True)

# Main script
if __name__ == "__main__":
    # Parameters and paths
    # input_dir = '/home/LifeSci/wenlab/hefengcs/VCD_dataset/input5000_location'
    # gt_dir = '/gpfs/home/LifeSci/wenlab/hefengcs/VCD_dataset/fish1_gt_RLD60'
    bz = 1
    #Ir = 1 * 1e-4
    Ir = bz * 1 * 1e-4
    lf_extra = 27  # Number of input channels
    n_slices = 300  # Number of output slices
    output_size = (600, 600)  # Output size
    tag ='11_22_baseline_only_fixed_snr_msssim_low_data21k'

    # train_input_dir='/home/LifeSci/wenlab/hefengcs/VCD_dataset/moving_fish2/fish2_input_location'
    # train_gt_dir = '/home/LifeSci/wenlab/hefengcs/VCD_dataset/moving_fish2/fish2_gt_RLD60'

    #固态：
    #机械：


    # train_input_dir='/mnt/raid/VCD_dataset/moving_fish2/fish2_input_location'
    # train_gt_dir = '/mnt/raid/VCD_dataset/moving_fish2/fish2_gt_RLD60'


    train_list ='/home/LifeSci/wenlab/hefengcs/VCD_torch_gnode05/data/data_div/mini_dataset_m2_1500/train_val1500.txt'


    # validation_input_dir = train_input_dir
    # validation_gt_dir =train_gt_dir
    val_list ='/home/LifeSci/wenlab/hefengcs/VCD_torch_gnode05/data/data_div/mini_dataset_m2_1500/test_val1500.txt'


    #
    # #计算训练集的百分位
    # initial_transform = transforms.Compose([transforms.ToTensor()])
    # dataset = CustomTiffDataset(input_dir=train_input_dir, gt_dir=train_gt_dir, input_transform=initial_transform)
    # dataloader = DataLoader(dataset, batch_size=bz, shuffle=True,num_workers=64)
    # train_input_min, train_input_max, train_gt_min, train_gt_max = compute_percentiles(dataloader,save_path='/gpfs/home/LifeSci/wenlab/hefengcs/VCD_torch_gnode05/data/data_div/fish1/per_fish1_train1500.npy')
    #
    # #计算验证集的百分位
    # dataset = CustomTiffDataset(input_dir=validation_input_dir, gt_dir=validation_gt_dir, input_transform=initial_transform)
    # dataloader = DataLoader(dataset, batch_size=bz, shuffle=True,num_workers=64)
    # val_input_min, val_input_max, val_gt_min, val_gt_max = compute_percentiles(dataloader,save_path='/gpfs/home/LifeSci/wenlab/hefengcs/VCD_torch_gnode05/data/data_div/fish1/per_fish1_val500.npy')
    #




    #tag = 'NAFNet_deeper_relu_PSNR_conv_RLD60_fish2_1500_0923_with_low32_pretrained_no_aug_percentile_0.5_99.5'

    label = tag
    #checkpoint_path = '/home/LifeSci/wenlab/hefengcs/VCD_torch_gnode05/ckpt/10_20_all/epoch=65-val_loss=-0.9089328051.ckpt'
    main_dir = '/home/LifeSci/wenlab/hefengcs/VCD_torch_gnode05'
    ckpt_dir = os.path.join(main_dir, 'ckpt', label)


    sample_dir = os.path.join(main_dir, 'sample', label)
    log_dir = os.path.join(main_dir, 'logs', label)
    os.makedirs(log_dir, exist_ok=True)
    os.makedirs(sample_dir, exist_ok=True)
    os.makedirs(ckpt_dir, exist_ok=True)




    # Initial transform for computing min and max values


    # Data transformations
  #   train_input_transform = transforms.Compose([
  #
  # # Convert from numpy array to PIL Image
  #       transforms.RandomHorizontalFlip(p=0.5),  # 随机水平翻转
  #       transforms.RandomVerticalFlip(p=0.5),  # 随机垂直翻转
  #       transforms.RandomRotation(degrees=(-30, 30)),  # 在-30到30度之间随机旋转
  #       transforms.ToTensor(),
  #       #transforms.ColorJitter(brightness=0.2, contrast=0.2, saturation=0.2, hue=0.1)
  #       # minmax_percentile_normalize(train_input_min, train_input_max)  # 正规化
  #   ])
  #   train_gt_transform =train_input_transform

    # train_transform = Compose([
    #     RandomHorizontalFlip(p=0.5),  # 50% 概率水平翻转
    #     RandomVerticalFlip(p=0.5),  # 50% 概率垂直翻转
    #     RandomRotation(p=0.5),  # 只旋转
    #     ToTensor(),  # 转换为 Tensor 形式
    # ])

    #train_transform = transforms.Compose([transforms.ToTensor()])


    train_transform = Compose([
        RandomHorizontalFlip(p=0.5),  # 50% 概率水平翻转
        RandomVerticalFlip(p=0.5),  # 50% 概率垂直翻转
        RandomRotation(p=0.5),  # 只旋转
        RandomGaussianNoise(p=0.5),
        RandomGaussianBlur(p=0.5),
        RandomBrightness(p=0.5),
        RandomContrast(p=0.5),
        ToTensor(),  # 转换为 Tensor 形式
    ])




    # Validation transforms (no augmentation, just normalization)
    val_input_transform = transforms.Compose([
        transforms.ToTensor(),

        # MinMaxNormalize(val_input_min, val_input_max)
    ])

    val_gt_transform = transforms.Compose([
        transforms.ToTensor(),
        # MinMaxNormalize(val_gt_min, val_gt_max)
    ])
    # Data module
    #data_module = TiffDataModule(input_dir, gt_dir, bz, input_transform, gt_transform)
    data_module = TiffDataModule(
        # train_input_dir=train_input_dir,
        # train_gt_dir=train_gt_dir,
        # val_input_dir=validation_input_dir,
        # val_gt_dir=validation_gt_dir,
        train_list=train_list,
        val_list=val_list,
        batch_size=bz,
        train_input_transform=val_input_transform,
        train_gt_transform=val_gt_transform,
        train_transform =None,
        val_input_transform=val_input_transform,
        val_gt_transform=val_gt_transform
    )
    # Model module
    # model_module = UNetLightningModule.load_from_checkpoint(
    #     checkpoint_path=checkpoint_path,
    #     lf_extra=lf_extra,
    #     n_slices=n_slices,
    #     output_size=output_size,
    #     learning_rate=Ir,
    #     input_min_val=input_min_val,
    #     input_max_val=input_max_val,
    #     gt_min_val=gt_min_val,
    #     gt_max_val=gt_max_val,
    #     strict=False
    # )


    model_module = UNetLightningModule(learning_rate=Ir)

    #
    # # 获取模型的 state_dict
    # checkpoint = torch.load(checkpoint_path)
    # model_state_dict = model_module.state_dict()
    #
    # # 对比检查点的 state_dict 和当前模型的 state_dict，只加载匹配的部分
    # checkpoint_state_dict = {k: v for k, v in checkpoint['state_dict'].items() if
    #                          k in model_state_dict and model_state_dict[k].shape == v.shape}
    #
    # # 更新模型参数
    # model_state_dict.update(checkpoint_state_dict)
    # model_module.load_state_dict(model_state_dict)



    # Callbacks
    checkpoint_callback = pl.callbacks.ModelCheckpoint(
        dirpath=ckpt_dir,
        save_top_k=1,
        monitor='val_loss',
        mode='min',
        filename='{epoch}-{val_loss:.10f}'
    )
    lr_monitor = pl.callbacks.LearningRateMonitor(logging_interval='epoch')
    save_inference_callback = SaveInferenceCallback(sample_dir, epoch_interval=10)

    # Logger
    logger = pl.loggers.TensorBoardLogger(log_dir)



    # Trainer
    trainer = pl.Trainer(
        max_epochs=250,
        devices=4,
        accelerator='gpu',
        #strategy='ddp_find_unused_parameters_true',
        strategy='ddp_spawn',
        callbacks=[checkpoint_callback, lr_monitor,save_inference_callback],
        logger=logger,
        log_every_n_steps=50,
        #precision='16-mixed'
    )


    trainer.fit(model_module,datamodule=data_module)