import os

from datetime import datetime
import torch
import torch.nn as nn
import torch.optim as optim
import torchvision.transforms as transforms
import tifffile as tiff
from torch.utils.data import DataLoader, random_split
import pytorch_lightning as pl
from pytorch_lightning import Trainer
from pytorch_lightning.callbacks import ModelCheckpoint, LearningRateMonitor
from pytorch_lightning.loggers import TensorBoardLogger
import sys
sys.path.append('/gpfs/home/LifeSci/wenlab/hefengcs/VCD_torch_gnode05')
torch.set_float32_matmul_precision('high')
os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "expandable_segments:True"
from model.model import UNet
from model.model import UNet  # 确保你的路径正确
from dataset import CustomTiffDataset, compute_min_max, MinMaxNormalize  # 确保你的路径正确
from loss import sobel_edges, l2_loss, edges_loss, SSIMLoss  # 确保你的路径正确

class VCDModel(pl.LightningModule):
    def __init__(self, lf_extra, n_slices, output_size, input_min_val, input_max_val, gt_min_val, gt_max_val, lr, sample_dir):
        super(VCDModel, self).__init__()
        self.model = UNet(lf_extra, n_slices, output_size)
        self.criterion = nn.MSELoss()
        self.edges_loss = edges_loss
        self.ssim_loss_fn = SSIMLoss(size_average=True)
        self.lr = lr
        self.sample_dir = sample_dir
        self.validation_outputs = []
        self.training_outputs = []

        self.input_transform = transforms.Compose([
            transforms.ToTensor(),
            MinMaxNormalize(input_min_val, input_max_val)
        ])
        self.gt_transform = transforms.Compose([
            transforms.ToTensor(),
            MinMaxNormalize(gt_min_val, gt_max_val)
        ])

    def forward(self, x):
        return self.model(x)

    def configure_optimizers(self):
        optimizer = optim.Adam(self.model.parameters(), lr=self.lr)
        scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer, 'min', patience=5)
        return {"optimizer": optimizer, "lr_scheduler": scheduler, "monitor": "val/loss"}

    def training_step(self, batch, batch_idx):
        inputs, labels = batch
        outputs = self(inputs)
        mse_loss = self.criterion(outputs, labels)
        edge_loss_value = self.edges_loss(outputs, labels)
        ssim_loss = self.ssim_loss_fn(outputs, labels)
        total_loss = mse_loss + 0.1 * edge_loss_value - torch.log((1 + ssim_loss) / 2)

        self.training_outputs.append(total_loss)

        self.log('train/loss', total_loss, on_epoch=True, on_step=False, sync_dist=True)
        self.log('train/mse_loss', mse_loss, on_epoch=True, on_step=False, sync_dist=True)
        self.log('train/edge_loss', edge_loss_value, on_epoch=True, on_step=False, sync_dist=True)
        self.log('train/ssim_loss', ssim_loss, on_epoch=True, on_step=False, sync_dist=True)
        return total_loss

    def validation_step(self, batch, batch_idx):
        inputs, labels = batch
        outputs = self(inputs)
        mse_loss = self.criterion(outputs, labels)
        edge_loss_value = self.edges_loss(outputs, labels)
        ssim_loss = self.ssim_loss_fn(outputs, labels)
        total_loss = mse_loss + 0.1 * edge_loss_value - torch.log((1 + ssim_loss) / 2)

        self.validation_outputs.append({"val_loss": total_loss, "outputs": outputs, "inputs": inputs})

        self.log('val/loss', total_loss, on_epoch=True, on_step=False, sync_dist=True)
        self.log('val/mse_loss', mse_loss, on_epoch=True, on_step=False, sync_dist=True)
        self.log('val/edge_loss', edge_loss_value, on_epoch=True, on_step=False, sync_dist=True)
        self.log('val/ssim_loss', ssim_loss, on_epoch=True, on_step=False, sync_dist=True)
        return total_loss

    def on_validation_epoch_end(self):
        avg_val_loss = torch.stack([x['val_loss'] for x in self.validation_outputs]).mean()
        self.log('val/loss_epoch', avg_val_loss, on_epoch=True, sync_dist=True)

        # 打印验证集损失
        # print(f"Epoch {self.current_epoch}: Val Loss: {avg_val_loss}")

        # 每10个epoch保存一次验证集结果
        if self.current_epoch % 10 == 0:
            sample_dir = os.path.join(self.sample_dir, f'epoch_{self.current_epoch}')
            os.makedirs(sample_dir, exist_ok=True)
            for i, output in enumerate(self.validation_outputs):
                inputs = output["inputs"]
                outputs = output["outputs"]
                output_filename = f"sample_{i}_epoch_{self.current_epoch}.tif"
                output_path = os.path.join(sample_dir, output_filename)
                image = outputs.cpu().numpy().squeeze()
                tiff.imwrite(output_path, image, compression="deflate")

        # 清除当前 epoch 的验证输出
        self.validation_outputs.clear()

    def on_train_epoch_end(self):
        # avg_train_loss = torch.stack(self.training_outputs).mean()
        # print(f"Epoch {self.current_epoch}: Train Loss: {avg_train_loss}")
        # self.training_outputs.clear()
        pass

class VCDDataModule(pl.LightningDataModule):
    def __init__(self, input_dir, gt_dir, batch_size):
        super().__init__()
        self.input_dir = input_dir
        self.gt_dir = gt_dir
        self.batch_size = batch_size

    def setup(self, stage=None):
        initial_transform = transforms.Compose([transforms.ToTensor()])
        dataset = CustomTiffDataset(input_dir=self.input_dir, gt_dir=self.gt_dir, input_transform=initial_transform)
        dataloader = DataLoader(dataset, batch_size=self.batch_size, shuffle=True)
        self.input_min_val, self.input_max_val, self.gt_min_val, self.gt_max_val = compute_min_max(dataloader)

        self.input_transform = transforms.Compose([
            transforms.ToTensor(),
            MinMaxNormalize(self.input_min_val, self.input_max_val)
        ])
        self.gt_transform = transforms.Compose([
            transforms.ToTensor(),
            MinMaxNormalize(self.gt_min_val, self.gt_max_val)
        ])

        dataset = CustomTiffDataset(input_dir=self.input_dir, gt_dir=self.gt_dir, input_transform=self.input_transform,
                                    gt_transform=self.gt_transform)
        total_size = len(dataset)
        test_size = int(0.1 * total_size)
        train_size = total_size - test_size
        self.train_dataset, self.test_dataset = random_split(dataset, [train_size, test_size])

    def train_dataloader(self):
        return DataLoader(self.train_dataset, batch_size=self.batch_size, shuffle=True,  num_workers=8)

    def val_dataloader(self):
        return DataLoader(self.test_dataset, batch_size=self.batch_size, shuffle=False,  num_workers=8)

if __name__ == '__main__':
    input_dir = '/gpfs/home/LifeSci/wenlab/hefengcs/VCD5.12/stack/input_crop'
    gt_dir = '/gpfs/home/LifeSci/wenlab/hefengcs/VCD5.12/stack/GT'
    batch_size = 1
    lf_extra = 27
    n_slices = 300
    output_size = (600, 600)
    num_epochs = 300
    lr = 1e-4 * batch_size

    current_time = datetime.now().strftime('%Y%m%d-%H%M%S')
    ckpt_dir = os.path.join('/gpfs/home/LifeSci/wenlab/hefengcs/VCD_torch_gnode05/ckpt', current_time)
    log_dir = os.path.join('/gpfs/home/LifeSci/wenlab/hefengcs/VCD_torch_gnode05/logs', current_time)
    sample_dir = os.path.join('/gpfs/home/LifeSci/wenlab/hefengcs/VCD_torch_gnode05/sample', current_time)
    os.makedirs(ckpt_dir, exist_ok=True)
    os.makedirs(log_dir, exist_ok=True)
    os.makedirs(sample_dir, exist_ok=True)

    data_module = VCDDataModule(input_dir=input_dir, gt_dir=gt_dir, batch_size=batch_size)
    data_module.setup()

    model = VCDModel(lf_extra, n_slices, output_size, data_module.input_min_val, data_module.input_max_val,
                     data_module.gt_min_val, data_module.gt_max_val, lr, sample_dir)

    checkpoint_callback = ModelCheckpoint(
        dirpath=ckpt_dir,
        save_top_k=1,
        monitor='val/loss',
        mode='min',
        filename='best_model-{epoch:03d}-{val_loss:.8f}'
    )
    lr_monitor = LearningRateMonitor(logging_interval='epoch')
    logger = TensorBoardLogger(log_dir)

    trainer = Trainer(
        max_epochs=num_epochs,
        devices=8,
        accelerator='gpu',
        strategy='ddp',
        callbacks=[checkpoint_callback, lr_monitor],
        logger=logger
    )

    trainer.fit(model, data_module)
