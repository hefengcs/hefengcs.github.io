#计算这两个文件夹的mse：/home/LifeSci/wenlab/hefengcs/VCD_dataset/fish1_gt_RLD60
#