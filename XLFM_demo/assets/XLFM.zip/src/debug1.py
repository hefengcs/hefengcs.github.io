# 获取 checkpoint 中的模型状态字典
import torch


