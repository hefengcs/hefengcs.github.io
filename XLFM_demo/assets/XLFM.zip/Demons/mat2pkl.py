import os
import numpy as np
import pickle
from scipy.io import loadmat
from concurrent.futures import ThreadPoolExecutor
from tqdm import tqdm

# 文件夹路径
demons_dir = "/home/LifeSci/wenlab/hefengcs/Registration_dataset/240903-2/Demons_g"
recon_dir = "/home/LifeSci/wenlab/hefengcs/Registration_dataset/240903-2/Recon_g"
output_dir = "/home/LifeSci/wenlab/hefengcs/Registration_dataset/240903-2/pkl/"

# 创建输出文件夹，如果不存在
os.makedirs(output_dir, exist_ok=True)

# 目标大小
target_shape = (600, 600, 300)

def pad_to_target(array, target_shape):
    """将数组补零到目标形状"""
    result = np.zeros(target_shape, dtype=np.float32)
    # 计算每个维度的实际数据范围
    z, y, x = array.shape
    result[:z, :y, :x] = array
    return result

def process_files(demons_file, recon_file, output_file):
    """读取、处理并保存配准和重建后的数据"""
    try:
        # 读取配准后的数据和重建后的数据
        demons_data = loadmat(demons_file).get('ObjRecon')
        recon_data = loadmat(recon_file).get('ObjRecon')

        # 检查数据是否读取成功
        if demons_data is None or recon_data is None:
            print(f"Error reading data from {demons_file} or {recon_file}.")
            return

        # 补零处理
        demons_data_padded = pad_to_target(demons_data, target_shape)

        # 转换为 float32
        demons_data_padded = demons_data_padded.astype(np.float32)
        recon_data = recon_data.astype(np.float32)

        # 保存到 pkl 文件
        with open(output_file, 'wb') as f:
            pickle.dump({'demons': demons_data_padded, 'recon': recon_data}, f)

        #print(f"Processed and saved: {output_file}")
    except Exception as e:
        print(f"Error processing {demons_file} and {recon_file}: {e}")

# 批量处理文件
demons_files = [f for f in os.listdir(demons_dir) if f.endswith(".mat")]

# 使用 tqdm 显示进度条
with ThreadPoolExecutor(max_workers=16) as executor:
    futures = []
    for demons_filename in demons_files:
        # 构造对应的文件路径
        demons_path = os.path.join(demons_dir, demons_filename)
        recon_filename = demons_filename.replace("Green_Demons", "Green_Recon")
        recon_path = os.path.join(recon_dir, recon_filename)
        output_filename = demons_filename.replace(".mat", ".pkl")
        output_path = os.path.join(output_dir, output_filename)

        # 检查重建后的数据是否存在
        if not os.path.exists(recon_path):
            print(f"Reconstruction file not found for: {demons_filename}")
            continue

        # 提交任务到线程池
        futures.append(executor.submit(process_files, demons_path, recon_path, output_path))

    # 使用 tqdm 追踪任务完成进度
    for future in tqdm(futures, desc="Processing files", total=len(futures)):
        future.result()  # 获取结果，以确保处理中的异常被捕获
