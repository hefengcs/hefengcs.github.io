#读取mat转换为tif
import numpy as np
from scipy.io import loadmat
import tifffile as tiff
mat_path='/mnt/raid/Recon_test/VCD_data_inference_300/back_up/CalTrace/water_corMap.mat'
mat_data = loadmat(mat_path)
cor_map = mat_data['cor_map']
cor_map = cor_map.T
cor_map = np.flip(cor_map, axis=0)
cor_map = np.flip(cor_map, axis=1)
cor_map = np.clip(cor_map, 0, 1)
cor_map = (cor_map * 255).astype(np.uint8)
tif_path = '/mnt/raid/Recon_test/VCD_data_inference_300/back_up/CalTrace/cor_map.tif'
tiff.imwrite(tif_path, cor_map)
