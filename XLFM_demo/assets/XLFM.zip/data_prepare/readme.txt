#第一个使用 input_crop来裁剪

#第二步同时转换mat


