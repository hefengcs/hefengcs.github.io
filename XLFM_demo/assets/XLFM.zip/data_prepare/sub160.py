import os
import numpy as np
import tifffile as tiff
from concurrent.futures import ThreadPoolExecutor
from tqdm import tqdm

# 输入和输出文件夹
input_folder = "/home/LifeSci/wenlab/hefengcs/VCD_dataset/moving_fish3/input_location_raw"  # 替换为你的输入文件夹路径
output_folder = "/home/LifeSci/wenlab/hefengcs/VCD_dataset/moving_fish3/input_location"  # 替换为你的输出文件夹路径

# 确保输出文件夹存在
os.makedirs(output_folder, exist_ok=True)

# 读取文件夹中的所有 TIFF 文件
def get_tiff_files(folder):
    return [f for f in os.listdir(folder) if f.endswith('.tiff') or f.endswith('.tif')]


def process_file(file_name):
    input_path = os.path.join(input_folder, file_name)
    output_path = os.path.join(output_folder, file_name)

    # 读取 TIFF 文件
    image = tiff.imread(input_path)

    # 确保数据类型为 int32，防止溢出
    image = image.astype(np.int32)

    # 减去 160 并进行 0 截断
    processed_image = np.maximum(image - 160, 0)

    # 保存结果时转换回原数据类型（比如 uint16）
    processed_image = processed_image.astype(np.uint16)
    tiff.imwrite(output_path, processed_image)

# 获取所有 TIFF 文件
files = get_tiff_files(input_folder)

# 使用多线程处理文件
with ThreadPoolExecutor() as executor:
    list(tqdm(executor.map(process_file, files), total=len(files), desc="Processing TIFF files"))

print("Processing completed.")
