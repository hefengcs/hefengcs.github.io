import os


def find_and_remove_extra_files(path1, path2):
    # 获取路径1和路径2中的所有 .tif 文件名
    files1 = {f for f in os.listdir(path1) if f.lower().endswith('.tif')}
    files2 = {f for f in os.listdir(path2) if f.lower().endswith('.tif')}

    # 找出路径1和路径2中各自多余的文件
    extra_in_path1 = files1 - files2
    extra_in_path2 = files2 - files1

    # 删除路径1中多余的文件
    for file in extra_in_path1:
        file_path = os.path.join(path1, file)
        try:
            os.remove(file_path)
            print(f"已删除路径1中的多余文件: {file_path}")
        except Exception as e:
            print(f"无法删除文件 {file_path}: {e}")

    # 删除路径2中多余的文件
    for file in extra_in_path2:
        file_path = os.path.join(path2, file)
        try:
            os.remove(file_path)
            print(f"已删除路径2中的多余文件: {file_path}")
        except Exception as e:
            print(f"无法删除文件 {file_path}: {e}")


# 示例路径（替换为你的路径）
path1 = '/home/LifeSci/wenlab/hefengcs/VCD_dataset/moving_fish3/input_location_clean'
path2 = '/home/LifeSci/wenlab/hefengcs/VCD_dataset/moving_fish3/g'

# 执行函数
find_and_remove_extra_files(path1, path2)
