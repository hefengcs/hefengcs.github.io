import os

# 文件夹路径
folder_path = "/home/LifeSci/wenlab/hefengcs/VCD_dataset/moving_fish5/RLDtest"

# 遍历文件夹中的文件
for filename in os.listdir(folder_path):
    if filename.endswith(".tif"):  # 只处理 .tif 文件
        old_file = os.path.join(folder_path, filename)
        new_file = os.path.join(folder_path, "m5_" + filename)

        # 重命名文件
        os.rename(old_file, new_file)

print("文件重命名完成！")
