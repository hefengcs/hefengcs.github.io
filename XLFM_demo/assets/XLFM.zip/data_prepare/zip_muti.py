import os
import tarfile
from concurrent.futures import ThreadPoolExecutor
from tqdm import tqdm

# 要压缩的目录路径
directory_to_compress = '/home/LifeSci/wenlab/hefengcs/VCD_torch_gnode05/sample/Green_Recon'
output_tar_file = '/home/LifeSci/wenlab/hefengcs/VCD_torch_gnode05/sample/Green_Recon.tar.gz'


# 定义压缩文件的函数
def add_file_to_tar(file_path, tar_handle):
    tar_handle.add(file_path, arcname=os.path.relpath(file_path, directory_to_compress))


# 压缩目录的函数
def compress_directory(directory_path, output_tar_path):
    # 获取所有文件列表
    files_to_compress = []
    for root, dirs, files in os.walk(directory_path):
        for file in files:
            file_path = os.path.join(root, file)
            files_to_compress.append(file_path)

    # 打开 tarfile 进行压缩
    with tarfile.open(output_tar_path, 'w:gz') as tarf:
        # 使用 tqdm 显示进度条，并通过多线程处理
        with ThreadPoolExecutor() as executor:
            list(tqdm(executor.map(lambda file: add_file_to_tar(file, tarf), files_to_compress),
                      total=len(files_to_compress)))


# 执行压缩操作
compress_directory(directory_to_compress, output_tar_file)
print(f"Directory {directory_to_compress} has been compressed into {output_tar_file}")
