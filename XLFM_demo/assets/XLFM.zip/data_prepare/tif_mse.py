import numpy as np
import tifffile as tiff
from skimage.metrics import structural_similarity as ssim

def calculate_mse(image1_path, image2_path):
    """
    计算两个 TIFF 图像文件之间的均方误差（MSE）
    :param image1_path: 第一个 TIFF 文件路径
    :param image2_path: 第二个 TIFF 文件路径
    :return: MSE 值
    """
    # 加载两个 TIFF 图像文件


    image1 = tiff.imread(image1_path)/2000
    image2 = tiff.imread(image2_path)/2000

    #image1和image大于20的部分
    image1[image1<0] = 0
    image2[image1<0] = 0

    # 确保两个图像尺寸一致
    if image1.shape != image2.shape:
        raise ValueError("两个图像的尺寸不一致，无法计算 MSE。")

    # 计算 MSE
    mse = np.mean((image1 - image2) ** 2)
    return mse

def calculate_ssim(image1_path, image2_path):
    """
    计算两个 TIFF 图像文件之间的结构相似性指数（SSIM）
    :param image1_path: 第一个 TIFF 文件路径
    :param image2_path: 第二个 TIFF 文件路径
    :return: SSIM 值
    """
    # 加载两个 TIFF 图像文件
    image1 = tiff.imread(image1_path)
    image2 = tiff.imread(image2_path)

    # 确保两个图像尺寸一致
    if image1.shape != image2.shape:
        raise ValueError("两个图像的尺寸不一致，无法计算 SSIM。")

    # 计算 SSIM
    ssim_value = ssim(image1, image2, data_range=image2.max() - image2.min())
    return ssim_value

# 输入两个 TIFF 文件的路径
image1_path = '/home/LifeSci/wenlab/hefengcs/VCD_dataset/fixed_fish/240529/RLD27/Green_Recon_0.tif'
image2_path = '/home/LifeSci/wenlab/hefengcs/VCD_dataset/fixed_fish/240529/RLD60/f1_00000000.tif'

# 计算 MSE 和 SSIM
mse_value = calculate_mse(image1_path, image2_path)
ssim_value = calculate_ssim(image1_path, image2_path)

print(f"两个 TIFF 文件之间的均方误差（MSE）为: {mse_value}")
print(f"两个 TIFF 文件之间的结构相似性指数（SSIM）为: {ssim_value}")
