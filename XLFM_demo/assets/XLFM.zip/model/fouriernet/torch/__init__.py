__version__ = "0.1"
from .fouriernet import *
