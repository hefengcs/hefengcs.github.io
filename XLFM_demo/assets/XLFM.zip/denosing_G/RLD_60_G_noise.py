import os
import glob
import numpy as np
import tifffile
from tqdm import tqdm
from concurrent.futures import ThreadPoolExecutor, as_completed

# 输入文件夹路径，包含原始 tif 文件
input_folder = '/home/LifeSci/wenlab/hefengcs/VCD_dataset/fixed_fish/240903-2/RLD60'
# 输出文件夹路径，用于保存带高斯噪声的图像
output_folder = '/home/LifeSci/wenlab/hefengcs/VCD_dataset/fixed_fish/240903-2/RLD_60_G_noise'

# 如果输出文件夹不存在，则创建它
if not os.path.exists(output_folder):
    os.makedirs(output_folder)

# 定义高斯噪声参数（均值为0，标准差根据需求设置）
mu = 0
sigma = 10  # 可根据实际情况调整标准差

# 获取所有 tif 文件路径
tif_files = glob.glob(os.path.join(input_folder, '*.tif'))


def process_file(file):
    try:
        # 读取图像（支持单通道或多通道）
        img = tifffile.imread(file)

        # 转换为浮点数，便于噪声运算
        img_float = img.astype(np.float32)

        # 生成与图像大小相同的高斯噪声
        noise = np.random.normal(mu, sigma, img_float.shape)

        # 将噪声添加到原始图像上
        noisy_img = img_float + noise

        # 根据图像数据类型（如 uint8）进行截断（若需要限制在 0-255 范围内）
        # noisy_img = np.clip(noisy_img, 0, 255)

        # 恢复原始数据类型
        noisy_img = noisy_img.astype(img.dtype)

        # 构造输出文件路径，保持相同文件名
        base_name = os.path.basename(file)
        output_path = os.path.join(output_folder, base_name)

        # 保存带噪图像
        tifffile.imwrite(output_path, noisy_img)
        return output_path
    except Exception as e:
        print(f"Error processing {file}: {e}")
        return None


# 设置线程池中线程数量（可根据机器性能调整）
max_workers = 16

with ThreadPoolExecutor(max_workers=max_workers) as executor:
    # 提交所有任务到线程池
    futures = {executor.submit(process_file, file): file for file in tif_files}

    # 使用 tqdm 显示进度
    for future in tqdm(as_completed(futures), total=len(futures)):
        output_path = future.result()
        if output_path:
            print(f"已保存带噪图像: {output_path}")
