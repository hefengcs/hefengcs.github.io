import os
import torch
import tifffile as tiff
import torchvision.transforms as transforms
from torch.utils.data import DataLoader, Dataset
from pytorch_lightning import Trainer
from pytorch_lightning.callbacks import ModelCheckpoint, LearningRateMonitor
from pytorch_lightning.loggers import TensorBoardLogger
from tqdm import tqdm
import pytorch_lightning as pl
from src.dataset import compute_min_max, MinMaxNormalize
from utils.head import CombinedModel
from model.model import UNet_Transpose, UNet_Deeper
from src.loss import SSIMLoss
import numpy as np

# 定义一个用于推理的Dataset类
class CustomTiffInferenceDataset(Dataset):
    def __init__(self, input_dir, input_transform=None):
        self.input_dir = input_dir
        self.input_transform = input_transform
        self.image_files = os.listdir(input_dir)

    def __len__(self):
        return len(self.image_files)

    def __getitem__(self, idx):
        # 加载输入图像
        img_name = self.image_files[idx]
        input_path = os.path.join(self.input_dir, img_name)
        input_image = tiff.imread(input_path).astype(np.float32)
        input_image = np.transpose(input_image, (1, 2, 0))

        if self.input_transform:
            input_image = self.input_transform(input_image)

        return input_image, img_name


# 定义Lightning Module类
class UNetLightningModule(pl.LightningModule):
    def __init__(self, lf_extra, n_slices, output_size, learning_rate, input_min_val, input_max_val, gt_min_val,
                 gt_max_val):
        super(UNetLightningModule, self).__init__()
        self.model = CombinedModel()
        self.criterion = torch.nn.MSELoss()
        self.SSIM_loss = SSIMLoss(size_average=True)
        self.learning_rate = learning_rate
        self.input_min_val = input_min_val
        self.input_max_val = input_max_val
        self.gt_min_val = gt_min_val
        self.gt_max_val = gt_max_val

    def forward(self, x):
        return self.model(x)

    def configure_optimizers(self):
        return torch.optim.Adam(self.model.parameters(), lr=self.learning_rate)


# 推理部分
if __name__ == "__main__":
    # 参数和路径
    input_dir = '/gpfs/home/LifeSci/wenlab/hefengcs/VCD_dataset/input900'
    output_dir = '/gpfs/home/LifeSci/wenlab/hefengcs/VCD_torch_gnode05/test_ouput/NAFNet900'
    checkpoint_path = '/gpfs/home/LifeSci/wenlab/hefengcs/VCD_torch_gnode05/ckpt/NAFNet_072220240722-214858/epoch=240-val_loss=0.00.ckpt'

    bz = 1
    lf_extra = 27  # 输入通道数
    n_slices = 300  # 输出切片数
    output_size = (600, 600)  # 输出尺寸
    Ir = 1 * 1e-4

    # 加载已训练模型
    model_module = UNetLightningModule.load_from_checkpoint(checkpoint_path, lf_extra=lf_extra, n_slices=n_slices,
                                                            output_size=output_size, learning_rate=Ir,
                                                            input_min_val=None, input_max_val=None, gt_min_val=None,
                                                            gt_max_val=None)
    model_module.input_min_val=0
    model_module.input_max_val=1139

    # 准备数据变换
    input_transform = transforms.Compose([
        transforms.ToTensor(),
        MinMaxNormalize(model_module.input_min_val, model_module.input_max_val)
    ])

    # 创建数据集和数据加载器用于推理
    inference_dataset = CustomTiffInferenceDataset(input_dir=input_dir, input_transform=input_transform)
    dataloader = DataLoader(inference_dataset, batch_size=bz, shuffle=False)

    # 推理
    model_module.eval()
    model_module.to('cuda' if torch.cuda.is_available() else 'cpu')
    with torch.no_grad():
        for inputs, img_name in tqdm(dataloader):
            inputs = inputs.to(model_module.device)
            outputs = model_module(inputs)

            # 保存输出文件
            for i in range(len(img_name)):
                output_filename = f"{os.path.splitext(img_name[i])[0]}_output.tif"
                output_path = os.path.join(output_dir, output_filename)
                os.makedirs(os.path.dirname(output_path), exist_ok=True)
                image = outputs[i].cpu().numpy().squeeze()
                tiff.imwrite(output_path, image, compression="deflate")

    print("推理完成。")
