import h5py
import pytorch_lightning as pl
import tifffile
import torch
from numpy.matrixlib.defmatrix import matrix
from torch.optim import Adam
from torch.optim.lr_scheduler import ReduceLROnPlateau

from src.loss import consistency_loss_log
from utils.LossManager import LossManager
torch.set_float32_matmul_precision('high')
import torch.nn as nn
class UNetLightningModule(pl.LightningModule):
    def __init__(self, model, loss_config, learning_rate,batch_size,PSF_flag=False,PSF_ratio=2e-2):
        """
        初始化 Lightning 模块
        :param model: 模型实例
        :param loss_config: 损失配置
        :param learning_rate: 学习率
        """
        super().__init__()
        self.model = model
        self.loss_manager = LossManager(loss_config)
        self.learning_rate = learning_rate
        self.relu = nn.ReLU()
        self.batch_size = batch_size
        self.PSF_flag = PSF_flag
        if self.PSF_flag:
            h5_path = '/gpfs/home/LifeSci/wenlab/hefengcs/VCD_torch_gnode05/RLD_test/PSF_G.mat'
            tif_path ='/home/LifeSci/wenlab/hefengcs/VCD_dataset/PSF_ideal/combined_PSF.tif'
            self.PSF = self.read_hdf5(h5_path)
            self.PSF_ratio =PSF_ratio
            #self.PSF =self.read_tiff(tif_path)
    def read_tiff(self, tiff_path):
            matrix = tifffile.imread(tiff_path)
            matrix = torch.tensor(matrix, dtype=torch.float32)
            return matrix

    def read_hdf5(self, h5_path):
        with h5py.File(h5_path, 'r') as f:
            matrix = f['PSF_1'][:]
            matrix = torch.tensor(matrix, dtype=torch.float32)
            matrix = matrix.permute(0, 2, 1)
        return matrix

    def pad_to_target(self, matrix, target_size):
        matrix = matrix.squeeze(0)
        padded_matrix = torch.zeros(target_size, dtype=matrix.dtype, device=matrix.device)
        z_start = (target_size[0] - matrix.size(0)) // 2
        y_start = (target_size[1] - matrix.size(1)) // 2
        x_start = (target_size[2] - matrix.size(2)) // 2

        padded_matrix[z_start:z_start + matrix.size(0),
        y_start:y_start + matrix.size(1),
        x_start:x_start + matrix.size(2)] = matrix
        return padded_matrix

    def setup(self, stage=None):
        # 在这里确保 PSF 的设备与模型一致
        # def ifftshift(x):
        #     shift = [-(dim // 2) for dim in x.shape]
        #     return torch.roll(x, shift, dims=(-2, -1))
        def ifftshift(x):
            shift = [-(dim // 2) for dim in x.shape[-2:]]  # 只计算最后两个维度的shift
            return torch.roll(x, shift, dims=(-2, -1))  # 在最后两个维度上进行roll操作


        if self.PSF_flag:
            self.PSF = self.PSF.to(self.device)
            self.PSF = self.pad_to_target(self.PSF, (300, 2304, 2304))
            #先进行中心化
            self.PSF = ifftshift(self.PSF)
            self.PSF_fft = torch.fft.fft2(self.PSF)
            self.PSF_fft = self.PSF_fft.to(self.device)
            #清除self.PSF的显存
            self.PSF = None


    def forward(self, x):
        x = self.model(x)
        x = self.relu(x)
        return x

    def configure_optimizers(self):
        optimizer = Adam(self.model.parameters(), lr=self.learning_rate)
        scheduler = ReduceLROnPlateau(
            optimizer, mode="min", factor=0.5, patience=3, verbose=True
        )
        return {
            "optimizer": optimizer,
            "lr_scheduler": {
                "scheduler": scheduler,
                "monitor": "val_loss"
            }
        }

    def training_step(self, batch, batch_idx):
        inputs, labels, _, _, _ = batch
        outputs = self(inputs)

        # 使用 LossManager 计算损失
        total_loss, individual_losses = self.loss_manager.compute_total_loss(outputs, labels)
        if self.PSF_flag:
            consistency_loss_value = consistency_loss_log(outputs, labels, self.PSF_fft, self.logger, self.global_step)
            total_loss += (consistency_loss_value/ self.PSF_ratio)
            self.log('train_consistency_loss', consistency_loss_value, sync_dist=True)
        # 记录日志
        self.log("train_loss", total_loss, sync_dist=True)
        for loss_name, loss_value in individual_losses.items():
            self.log(f"train_{loss_name}", loss_value, sync_dist=True)

        return total_loss

    def validation_step(self, batch, batch_idx):
        inputs, labels, _, _, _ = batch
        outputs = self(inputs)

        # 使用 LossManager 计算损失
        total_loss, individual_losses = self.loss_manager.compute_total_loss(outputs, labels)
        if self.PSF_flag:
            consistency_loss_value = consistency_loss_log(outputs, labels, self.PSF_fft, self.logger, self.global_step)
            total_loss += (consistency_loss_value/ self.PSF_ratio)
            self.log('val_consistency_loss', consistency_loss_value, sync_dist=True)

        # 记录日志
        self.log("val_loss", total_loss,batch_size= self.batch_size,sync_dist=True)
        for loss_name, loss_value in individual_losses.items():
            self.log(f"val_{loss_name}", loss_value,batch_size= self.batch_size, sync_dist=True)


        return total_loss
