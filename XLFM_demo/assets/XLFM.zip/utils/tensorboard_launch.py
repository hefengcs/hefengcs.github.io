import subprocess
import time
#log_dir = "/mnt/myssd/models/VCD_torch/logs/NAFNet_deeper_relu_PSNR_conv_RLD60_fish1_5000_0907_with_low_pretrained_aug20240907-112921"
log_dir = "/home/LifeSci/wenlab/hefengcs/VCD_torch_gnode05/logs/Abl_no_Aug20240924-213520"
port='60008'
tensorboard_process = subprocess.Popen(['tensorboard', '--logdir', log_dir, '--host', '0.0.0.0','--port', port],
                                       stdout=subprocess.PIPE,
                                       stderr=subprocess.PIPE)
print("TensorBoard is running with PID, port:", tensorboard_process.pid, port)
try:
    while True:
        time.sleep(10)  # 让主进程继续运行而不退出
except KeyboardInterrupt:
    print("Shutting down TensorBoard.")
    tensorboard_process.terminate()  # 当你希望结束时，终止 TensorBoard 进程