import pytorch_lightning as pl
import os
import numpy as np
import tifffile as tiff
import torch


class SaveInferenceCallback(pl.Callback):
    def __init__(self, sample_dir, epoch_interval=20, is_inference=False):
        """
        Callback to save inference results during validation.

        Args:
            sample_dir (str): Directory to save the output files.
            epoch_interval (int): Interval at which epochs to save results (only for training).
            is_inference (bool): If True, save results for every validation step.
        """
        self.sample_dir = sample_dir
        self.epoch_interval = epoch_interval
        self.is_inference = is_inference

    def on_validation_epoch_end(self, trainer, pl_module):
        """
        Called at the end of each validation epoch.
        Saves inference results based on the mode (training or inference).
        """
        epoch = trainer.current_epoch
        if self.is_inference or (epoch % self.epoch_interval == 1):  # Save every step in inference mode
            val_loader = trainer.datamodule.val_dataloader()
            pl_module.model.eval()  # Set the model to evaluation mode
            with torch.no_grad():
                for idx, (inputs, labels, input_filename, low, high) in enumerate(val_loader):
                    inputs = inputs.to(pl_module.device)
                    outputs = pl_module(inputs)

                    # Construct the output file name
                    output_filename = f"{input_filename}_epoch{epoch + 1}.tif"
                    output_path = os.path.join(self.sample_dir, output_filename)
                    os.makedirs(os.path.dirname(output_path), exist_ok=True)

                    # Convert low, high, and outputs to numpy
                    low = low.cpu().numpy().astype(np.float32)
                    high = high.cpu().numpy().astype(np.float32)
                    image = outputs.cpu().numpy().squeeze()
                    image = image * (high - low) + low  # Scale the image back to original range

                    # Save the image as a tiff file
                    tiff.imwrite(output_path, image)
                pl_module.model.train()  # Return the model to training mode
