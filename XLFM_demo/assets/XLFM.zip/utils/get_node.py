import socket

# 获取主机名
hostname = socket.gethostname()

# 打印主机名
print("主机名:", hostname)
