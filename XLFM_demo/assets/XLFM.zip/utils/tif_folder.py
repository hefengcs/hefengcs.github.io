import os
import numpy as np
from tifffile import imread
from tqdm import tqdm
from concurrent.futures import ThreadPoolExecutor, as_completed

def list_tif_files(folder_path):
    """List all .tif files in the given folder."""
    return sorted([f for f in os.listdir(folder_path) if f.endswith('.tif')])

def calculate_mse(img1, img2):
    """Calculate the Mean Squared Error (MSE) between two images."""
    return np.mean((img1 - img2) ** 2)

def calculate_pair_mse(file1_path, file2_path):
    """Calculate MSE for a given pair of file paths."""
    img1 = imread(file1_path)/2000
    img2 = imread(file2_path)/2000

    # Ensure both images have the same shape
    if img1.shape != img2.shape:
        print(f"Skipping {os.path.basename(file1_path)} due to shape mismatch with {os.path.basename(file2_path)}.")
        return None

    # Calculate and return MSE
    return calculate_mse(img1, img2)

def calculate_mse_between_folders(folder1, folder2, max_workers=4):
    """Calculate the average MSE of matching .tif files between two folders using multithreading."""
    files1 = list_tif_files(folder1)
    files2 = list_tif_files(folder2)

    # Find common files in both folders
    common_files = set(files1).intersection(set(files2))
    if not common_files:
        print("No common .tif files found between the folders.")
        return

    total_mse = 0.0
    count = 0

    # ThreadPool for multithreading
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = []

        # Submit tasks to the executor for each common file
        for file_name in common_files:
            file1_path = os.path.join(folder1, file_name)
            file2_path = os.path.join(folder2, file_name)
            futures.append(executor.submit(calculate_pair_mse, file1_path, file2_path))

        # Use tqdm to show progress and accumulate results
        for future in tqdm(as_completed(futures), total=len(futures), desc="Calculating MSE"):
            mse_value = future.result()
            if mse_value is not None:
                total_mse += mse_value
                count += 1

    # Calculate the average MSE
    average_mse = total_mse / count if count > 0 else None
    if average_mse is not None:
        print(f"Average MSE between matching .tif files: {average_mse}")
    else:
        print("No matching .tif files with the same shape were found.")

# Usage:
folder1 = '/home/LifeSci/wenlab/hefengcs/VCD_dataset/fixed_fish/test/RLD60'
folder2 = '/home/LifeSci/wenlab/hefengcs/VCD_torch_gnode05/sample/11_19_test'

calculate_mse_between_folders(folder1, folder2, max_workers=16)
