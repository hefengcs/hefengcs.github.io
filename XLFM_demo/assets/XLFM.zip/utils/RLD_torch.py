import torch
import numpy as np

def fftshift(x):
    shift = [dim // 2 for dim in x.shape]
    return torch.roll(x, shift, dims=(-2, -1))

def reConstruct(imstack, init, PSF):
    """
    Function summary: reconstruct a frame using Richardson-Lucy Deconvolution (RLD).
    """
    # Basic parameters
    ItN = 2  # Number of iterations
    BkgMean = 120  # Background noise mean level
    ROISize = imstack.shape[1] // 2  # Region of interest size
    SNR = 200  # Signal-to-noise ratio
    NxyExt = 128  # Image extension size, ensure it is compatible with input size
    Nxy = PSF.shape[1] + NxyExt * 2  # Extended image size
    Nz = imstack.shape[0]  # Z-axis height

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"Using device: {device}")

    # Initialize the variables and transform to GPU
    BkgFilterCoef = 0.0
    x = torch.arange(-Nxy//2, Nxy//2, device=device).float()
    y = torch.arange(-Nxy//2, Nxy//2, device=device).float()
    x, y = torch.meshgrid(x, y, indexing='ij')
    R = torch.sqrt(x**2 + y**2)
    Rlimit = 20
    RWidth = 20
    BkgFilter = (torch.cos((R-Rlimit)/RWidth*np.pi)/2+0.5)*(R>=Rlimit)*(R<=(Rlimit+RWidth)) + (R<Rlimit)
    BkgFilter = torch.fft.ifftshift(BkgFilter)

    PSF = PSF.to(device).float()
    PSF = torch.nn.functional.pad(PSF, (NxyExt, NxyExt, NxyExt, NxyExt), 'constant', 0)

    gpuObjReconTmp = torch.zeros((Nxy, Nxy), device=device, dtype=torch.float32)
    ImgEst = torch.zeros((Nxy, Nxy), device=device, dtype=torch.float32)
    Ratio = torch.ones((Nxy, Nxy), device=device, dtype=torch.float32)
    Img = imstack.to(device).float()
    ImgMultiView = Img - BkgMean
    ImgMultiView = torch.clamp(ImgMultiView, min=0)
    ImgExp = torch.nn.functional.pad(ImgMultiView, (NxyExt, NxyExt, NxyExt, NxyExt), 'constant', 0)

    init = init.to(device).float()
    gpuObjRecon = torch.nn.functional.pad(init, (NxyExt, NxyExt, NxyExt, NxyExt), 'constant', 0)

    def calculate_tensor_entropy(tensor):
        tensor = (tensor - tensor.min()) / (tensor.max() - tensor.min()) * 255
        tensor = tensor.cpu().numpy().astype(np.uint8)
        tensor_flat = tensor.flatten()
        unique, counts = np.unique(tensor_flat, return_counts=True)
        probs = counts / counts.sum()
        entropy = -np.sum(probs * np.log2(probs + 1e-9))
        return entropy

    def ifftshift(x):
        shift0 = x.shape[0] // 2
        shift1 = x.shape[1] // 2
        shifted = torch.roll(x, shifts=(shift0, shift1), dims=(0, 1))
        return shifted

    for ii in range(ItN):
        ImgEst.fill_(0)
        for jj in range(Nz):
            gpuObjReconTmp[Nxy // 2 - ROISize:Nxy // 2 + ROISize, Nxy // 2 - ROISize:Nxy // 2 + ROISize] = gpuObjRecon[jj, :, :]

            PSF_jj = PSF[:, :, jj]
            fft_PSF = torch.fft.fft2(ifftshift(PSF_jj))

            ImgEst_slice_update = torch.real(torch.fft.ifft2(torch.fft.fft2(gpuObjReconTmp) * fft_PSF)) / torch.sum(PSF_jj)
            ImgEst += torch.max(ImgEst_slice_update, torch.tensor(0.0, device=ImgEst_slice_update.device))

        BkgEst = torch.real(torch.fft.ifft2(torch.fft.fft2(ImgExp - ImgEst) * BkgFilter)) * BkgFilterCoef
        ImgExpEst = ImgExp - BkgEst

        Tmp = torch.median(ImgEst)

        Ratio.fill_(1)
        Ratio[NxyExt:-NxyExt, NxyExt:-NxyExt] = ImgExpEst[NxyExt:-NxyExt, NxyExt:-NxyExt] / (ImgEst[NxyExt:-NxyExt, NxyExt:-NxyExt] + Tmp / SNR)

        for jj in range(Nz):
            PSF_jj = PSF[:, :, jj]
            PSF_jj_shifted = ifftshift(PSF_jj)
            fft_PSF = torch.fft.fft2(PSF_jj_shifted)
            fft_PSF_conj = torch.conj(fft_PSF)
            fft_Ratio = torch.fft.fft2(Ratio)

            ifft_result = torch.fft.ifft2(fft_Ratio * fft_PSF_conj)
            gpuTmp = torch.real(ifft_result) / torch.sum(PSF_jj)
            gpuTmp = torch.maximum(gpuTmp, torch.tensor(0.0, device=device))

            gpuObjRecon[jj, :, :] *= gpuTmp[Nxy // 2 - ROISize:Nxy // 2 + ROISize, Nxy // 2 - ROISize:Nxy // 2 + ROISize]

    ObjRecon = gpuObjRecon.cpu().numpy().astype(np.float32)
    return ObjRecon

# Generate random test data
def generate_random_data(Nxy, Nz):
    imstack = torch.rand((Nz, Nxy, Nxy))
    init = torch.rand((Nz, Nxy, Nxy))
    PSF = torch.rand((Nz, Nxy, Nxy))
    return imstack, init, PSF

# Parameters
Nxy = 600
Nz = 300

# Generate random data
imstack, init, PSF = generate_random_data(Nxy, Nz)

# Test reConstruct function
ObjRecon = reConstruct(imstack, init, PSF)
print("Reconstruction complete.")
