import torch
import pytorch_lightning as pl
from src.dataset import CustomTiffDataset, compute_min_max, MinMaxNormalize,CustomTiffDataset_FP, SynchronizedTransform, ValTransform, compute_percentiles,minmax_percentile_normalize
from src.dataset import CustomTiffDatasetSinglePercentile,View_mask_dataset
from torch.utils.data import DataLoader, random_split

class TiffDataModule(pl.LightningDataModule):
    def __init__(self, train_list,val_list, batch_size, train_transform, val_transform,view_ratio=0):
        super().__init__()
        # self.train_input_dir = train_input_dir
        # self.train_gt_dir = train_gt_dir
        # self.val_input = val_input_dir
        # self.val_gt = val_gt_dir
        self.batch_size = batch_size
        # self.train_input_transform = train_input_transform
        # self.train_gt_transform = train_gt_transform
        # self.val_input_transform = val_input_transform
        # self.val_gt_transform = val_gt_transform
        self.train_list = train_list
        self.val_list =val_list
        self.train_transform = train_transform
        self.val_transform =val_transform
        self.view_ratio =view_ratio
    def setup(self, stage=None):
        # dataset = CustomTiffDataset(input_dir=self.input_dir, gt_dir=self.gt_dir, input_transform=self.train_input_transform, gt_transform=self.train_gt_transform)
        # total_size = len(dataset)
        # test_size = int(0.1 * total_size)
        # train_size = total_size - test_size
        # self.train_dataset, self.val_dataset = random_split(dataset, [train_size, test_size])
        #
        # # Validation dataset should use non-augmented transformations
        # self.val_dataset.dataset.input_transform = self.val_input_transform
        # self.val_dataset.dataset.gt_transform = self.val_gt_transform
        #创建训练集

        self.train_dataset = CustomTiffDatasetSinglePercentile( txt_file=self.train_list,train_transform=self.train_transform,view_ratio=self.view_ratio)
        #创建验证集
        self.val_dataset = CustomTiffDatasetSinglePercentile( txt_file=self.val_list,val_transform=self.val_transform,view_ratio=self.view_ratio)


    def train_dataloader(self):
        return DataLoader(self.train_dataset, batch_size=self.batch_size, shuffle=True, num_workers=4,pin_memory=True,persistent_workers=True)
        #2:39,10
        #4：40, 18
    def val_dataloader(self):
        return DataLoader(self.val_dataset, batch_size=self.batch_size, shuffle=False,  num_workers=4,pin_memory=True,persistent_workers=True)




class TiffData_Mask_Module(pl.LightningDataModule):
    def __init__(self, train_list,val_list, batch_size, train_transform, val_transform,ratio_pattern,ratio):
        super().__init__()
        # self.train_input_dir = train_input_dir
        # self.train_gt_dir = train_gt_dir
        # self.val_input = val_input_dir
        # self.val_gt = val_gt_dir
        self.batch_size = batch_size
        # self.train_input_transform = train_input_transform
        # self.train_gt_transform = train_gt_transform
        # self.val_input_transform = val_input_transform
        # self.val_gt_transform = val_gt_transform
        self.train_list = train_list
        self.val_list =val_list
        self.train_transform = train_transform
        self.val_transform =val_transform
        self.ratio_pattern =ratio_pattern
        self.ratio=ratio
    def setup(self, stage=None):
        # dataset = CustomTiffDataset(input_dir=self.input_dir, gt_dir=self.gt_dir, input_transform=self.train_input_transform, gt_transform=self.train_gt_transform)
        # total_size = len(dataset)
        # test_size = int(0.1 * total_size)
        # train_size = total_size - test_size
        # self.train_dataset, self.val_dataset = random_split(dataset, [train_size, test_size])
        #
        # # Validation dataset should use non-augmented transformations
        # self.val_dataset.dataset.input_transform = self.val_input_transform
        # self.val_dataset.dataset.gt_transform = self.val_gt_transform
        #创建训练集

        self.train_dataset = View_mask_dataset( txt_file=self.train_list,train_transform=self.train_transform,ratio_pattern=self.ratio_pattern,ratio=self.ratio)
        #创建验证集
        self.val_dataset = View_mask_dataset( txt_file=self.val_list,val_transform=self.val_transform,ratio_pattern=self.ratio_pattern,ratio=self.ratio)


    def train_dataloader(self):
        #return DataLoader(self.train_dataset, batch_size=self.batch_size, shuffle=True, num_workers=2,pin_memory=True,persistent_workers=True,prefetch_factor=8)
        return DataLoader(self.train_dataset, batch_size=self.batch_size, shuffle=True, num_workers=4)
        #2:39,10
        #4：40, 18
    def val_dataloader(self):
        #return DataLoader(self.val_dataset, batch_size=self.batch_size, shuffle=False,  num_workers=2,pin_memory=True,persistent_workers=True,prefetch_factor=8)

        return DataLoader(self.val_dataset, batch_size=self.batch_size, shuffle=False, num_workers=4)
