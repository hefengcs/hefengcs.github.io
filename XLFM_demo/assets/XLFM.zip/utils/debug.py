import os

def list_tif_files(folder_path):
    """List all .tif files in the given folder."""
    return {f for f in os.listdir(folder_path) if f.endswith('.tif')}

def compare_tif_files(folder1, folder2):
    """Compare .tif files between two folders."""
    files1 = list_tif_files(folder1)
    files2 = list_tif_files(folder2)

    only_in_folder1 = sorted(files1 - files2)
    only_in_folder2 = sorted(files2 - files1)

    print("Files only in folder 1:")
    for file in only_in_folder1:
        print(file)

    print("\nFiles only in folder 2:")
    for file in only_in_folder2:
        print(file)

# Usage:
folder1 = '/home/LifeSci/wenlab/hefengcs/VCD_dataset/moving_fish5/RLDtest'
folder2 = '/home/LifeSci/wenlab/hefengcs/VCD_dataset/moving_fish5/split_g/g6'

compare_tif_files(folder1, folder2)
