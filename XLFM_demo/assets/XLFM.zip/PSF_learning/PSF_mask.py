import numpy as np
import tifffile as tiff
import matplotlib.pyplot as plt
from tqdm import tqdm


# 加载 PSF 图像
def load_psf_image(psf_path):
    """
    读取给定路径的 PSF 图像
    """
    psf_image = tiff.imread(psf_path)
    if psf_image is None:
        print("无法加载PSF图像，请检查文件路径。")
        return None
    return psf_image


# 生成最终的 PSF 图像
def generate_psf_image(psf_image, coordinates, mask_index):
    """
    根据坐标和 PSF 图像生成单个 PSF
    """
    # 获取当前的坐标
    y1, x1, y2, x2 = coordinates[mask_index]

    # 如果坐标为 -1，跳过此生成
    if y1 == -1 or x1 == -1 or y2 == -1 or x2 == -1:
        print(f"跳过第 {mask_index + 1} 个坐标，原因：无效坐标")
        return None

    # 创建一个空白图像，大小与原始 PSF 图像一致
    # psf_result = np.zeros_like(psf_image)
    #
    # # 提取有效区域的 PSF，并保留为结果
    # psf_result[:, y1:y2 + 1, x1:x2 + 1] = psf_image[:, y1:y2 + 1, x1:x2 + 1]
    psf_result = np.copy(psf_image)

    # 将指定区域设置为 0（掩蔽指定区域）
    psf_result[:, y1:y2 + 1, x1:x2 + 1] = 0

    return psf_result


# 显示图像
def show_image(image, title="Image"):
    plt.imshow(image, cmap='gray')
    plt.title(title)
    plt.axis('off')
    plt.show()


# 保存图像
def save_image(image, save_path, mask_index):
    """
    保存每一层生成的 PSF 图像
    """
    save_file_path = f"{save_path}PSF_{mask_index + 1}.tif"
    tiff.imwrite(save_file_path, image)
    return save_file_path


# 主函数
psf_path = '/mnt/raid/VCD_dataset/PSF_G.tif'  # PSF 图像路径
np_path = '/home/hefengcs/models/VCD_dataset/PSF_masks/coordinates.npy'  # 坐标路径
save_path = '/mnt/raid/VCD_dataset/PSF_learning/PSF_inverse/'  # 保存路径

# 加载 PSF 图像和坐标
psf_image = load_psf_image(psf_path)
coordinates = np.load(np_path)

if psf_image is not None and coordinates is not None:
    # 遍历所有的坐标
    for mask_index in tqdm(range(coordinates.shape[0]), desc="Processing PSF Masks"):
        # 生成单个 PSF
        psf_result = generate_psf_image(psf_image, coordinates, mask_index)

        if psf_result is not None:
            # 保存处理后的结果
            save_file_path = save_image(psf_result, save_path, mask_index)
            print(f"第 {mask_index + 1} 个 PSF 已保存到: {save_file_path}")
else:
    print("PSF 图像或坐标加载失败，请检查路径！")
