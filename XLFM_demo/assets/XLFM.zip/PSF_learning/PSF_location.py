import os
import tifffile as tiff
import numpy as np

# 定义路径和文件数量
folder_path = "/home/hefengcs/models/VCD_dataset/PSF_masks/"
num_files = 27

# 初始化一个数组用于存储结果
result_array = np.zeros((num_files, 4), dtype=int)

for i in range(1, num_files + 1):
    file_path = os.path.join(folder_path, f"Mask{i}.tif")
    if os.path.exists(file_path):
        # 读取 tiff 文件
        mask = tiff.imread(file_path)
        # 找到所有值为 255 的坐标
        indices = np.argwhere(mask == 255)

        if indices.size > 0:  # 确保有全255的区域
            # 获取左上角和右下角的坐标
            top_left = tuple(indices.min(axis=0))
            bottom_right = tuple(indices.max(axis=0))
            # 存储到数组中
            result_array[i - 1] = [top_left[0], top_left[1], bottom_right[0], bottom_right[1]]
        else:
            # 如果没有全255的区域，填充 -1 表示未找到
            result_array[i - 1] = [-1, -1, -1, -1]
    else:
        print(f"File {file_path} does not exist.")
        result_array[i - 1] = [-1, -1, -1, -1]

# 保存到 .npy 文件
output_path = "/home/hefengcs/models/VCD_dataset/PSF_masks/coordinates.npy"
np.save(output_path, result_array)
print(f"Coordinates saved to {output_path}")
