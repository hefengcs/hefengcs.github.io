import matplotlib.pyplot as plt

# 数据
data_sizes = [500, 800, 1000, 1200]
val_mse = [3.5, 3.1, 3.64, 2.64]
extra_data_size = [800]
extra_val_mse = [2.51]

# 绘制折线图（蓝色线条）
plt.plot(data_sizes, val_mse, marker='o', linestyle='-', color='b')

# 绘制单独的红色点
plt.scatter(extra_data_size, extra_val_mse, color='r', zorder=5)

# 设置图表标题和标签
plt.title('Effect of Data Size on MSE')
plt.xlabel('Data Size')
plt.ylabel('Validation MSE')

# 显示图表
plt.grid(True)
plt.show()
