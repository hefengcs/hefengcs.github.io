import numpy as np
import tifffile as tiff
import matplotlib.pyplot as plt
import cv2


# 加载 PSF 图像
def load_psf_image(psf_path):
    # 使用tifffile读取tiff图像
    psf_image = tiff.imread(psf_path)
    if psf_image is None:
        print("无法加载PSF图像，请检查文件路径。")
        return None
    return psf_image


# 创建 mask，通过给定的对角线的两个点
def create_mask(image_shape, point1, point2):
    # 计算矩形的上下边界
    x_min, y_min = min(point1[0], point2[0]), min(point1[1], point2[1])
    x_max, y_max = max(point1[0], point2[0]), max(point1[1], point2[1])

    # 创建一个与图像相同大小的全零数组
    mask = np.zeros(image_shape, dtype=np.uint8)

    # 使用给定的对角点填充矩形区域为 255
    mask[y_min:y_max, x_min:x_max] = 255  # 仅保留矩形区域
    return mask


# 应用mask到PSF图像
def apply_mask_to_psf(psf_image, mask):
    # 如果是3D图像，逐层应用mask
    if len(psf_image.shape) == 3:
        result_image = np.zeros_like(psf_image)
        for z in range(psf_image.shape[0]):
            result_image[z] = cv2.bitwise_and(psf_image[z], psf_image[z], mask=mask)
        return result_image
    else:
        # 如果是2D图像
        return cv2.bitwise_and(psf_image, psf_image, mask=mask)


# 显示图像
def show_image(image, title="Image"):
    plt.imshow(image, cmap='gray')
    plt.title(title)
    plt.axis('off')
    plt.show()


# 保存图像
def save_image(image, save_path):
    tiff.imwrite(save_path, image)


# 示例：给定对角线的两个点
point1 = (1392, 1515)  # 对角点1
point2 = (1818, 1842)  # 对角点2
psf_path = '/home/LifeSci/wenlab/hefengcs/VCD_dataset/PSF_G.tif'  # PSF图像路径
save_path = '/mnt/raid/VCD_dataset/PSF_learning/PSF/PSF_G_single_ideal.tif'  # 保存路径
slice_index = 150  # 需要可视化的层（假设为第150层）

# 加载PSF图像
psf_image = load_psf_image(psf_path)
if psf_image is not None:
    # 创建mask
    mask = create_mask(psf_image.shape[1:], point1, point2)  # 仅考虑图像的x, y维度

    # 应用mask
    result_image = apply_mask_to_psf(psf_image, mask)

    # 如果是3D图像，提取第150层进行可视化
    if len(result_image.shape) == 3 and slice_index < result_image.shape[0]:
        slice_image = result_image[slice_index]
        show_image(slice_image, title=f"Masked PSF Image - Slice {slice_index}")
    else:
        # 如果是2D图像，直接显示
        show_image(result_image, title="Masked PSF Image")

    # 保存结果
    save_image(result_image, save_path)
    print(f"图像已保存到: {save_path}")
