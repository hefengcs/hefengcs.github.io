import numpy as np
import tifffile as tiff
import os
from tqdm import tqdm
from concurrent.futures import ThreadPoolExecutor

def generate_3d_sphere(image, center, radius):
    """
    在三维图像中生成球形点源
    :param image: 3D 图像的 numpy 数组
    :param center: 球的中心 (z, y, x)
    :param radius: 球的半径
    :return: 在图像中填充球形点源
    """
    z, y, x = np.indices(image.shape)
    z_center, y_center, x_center = center

    # 计算球体范围内的点
    distance = (z - z_center)**2 + (y - y_center)**2 + (x - x_center)**2
    mask = distance <= radius**2

    # 将符合球体内的点设置为 1
    image[mask] = 1.0
    return image

def generate_3d_point_sources(shape, num_sources, radius_range=(10, 15)):
    """
    在三维空间内生成球形点源（珠子）
    :param shape: 3D 图像的大小 (z, y, x)
    :param num_sources: 点源的数量
    :param radius_range: 球体半径的范围
    :return: 带球形点源的 3D 图像
    """
    image = np.zeros(shape, dtype=np.float32)  # 使用float32数据类型
    z_dim, y_dim, x_dim = shape
    np.random.seed()  # 每次生成不同的点源位置

    for _ in range(num_sources):
        # 在 3D 空间内随机选择球形点源的位置
        z_pos = np.random.randint(0, z_dim)
        y_pos = np.random.randint(0, y_dim)
        x_pos = np.random.randint(0, x_dim)

        # 随机选择一个球的半径
        radius = np.random.randint(radius_range[0], radius_range[1])

        # 生成球形点源
        image = generate_3d_sphere(image, center=(z_pos, y_pos, x_pos), radius=radius)

    return image

def process_image(i, shape, num_sources, radius_range, output_directory):
    """
    生成和保存单张 3D 球形点源图像
    :param i: 图像编号
    :param shape: 3D 图像的大小 (z, y, x)
    :param num_sources: 点源的数量
    :param radius_range: 球体半径的范围
    :param output_directory: 保存的目录路径
    """
    point_sources = generate_3d_point_sources(shape, num_sources, radius_range)

    # 保存文件，命名为 1.tif, 2.tif, ..., num_images.tif
    output_filename = os.path.join(output_directory, f'{i}.tif')
    tiff.imwrite(output_filename, point_sources, dtype=np.float32)

def save_tiff_images_multithreaded(num_images, shape, num_sources, radius_range, output_directory, num_threads=64):
    """
    生成并保存多张 3D 球形点源图像，使用多线程加速
    :param num_images: 要生成的图像数量
    :param shape: 3D 图像的大小 (z, y, x)
    :param num_sources: 每张图像的点源数量
    :param radius_range: 每个球的半径范围 (最小半径, 最大半径)
    :param output_directory: 保存的目录路径
    :param num_threads: 使用的线程数量
    """
    if not os.path.exists(output_directory):
        os.makedirs(output_directory)

    # 使用 ThreadPoolExecutor 创建多线程池
    with ThreadPoolExecutor(max_workers=num_threads) as executor:
        # 提交任务给线程池，使用 tqdm 显示进度
        list(tqdm(executor.map(lambda i: process_image(i, shape, num_sources, radius_range, output_directory),
                              range(1, num_images + 1)), total=num_images))

# 参数设置
shape = (300, 600, 600)  # 3D 图像的大小 (z, y, x)
num_sources = 3          # 每张图像的点源数量
num_images = 1500        # 要生成的图像数量
radius_range = (10, 15)  # 点源（珠子）的半径范围
output_directory = '/gpfs/home/LifeSci/wenlab/hefengcs/VCD_dataset/PSF_learning/input1500'  # 修改为实际的保存路径

# 生成并保存 1500 张 TIFF 文件，使用 64 线程
save_tiff_images_multithreaded(num_images, shape, num_sources, radius_range, output_directory, num_threads=64)
