import os
import numpy as np
from PIL import Image
import tifffile as tiff
from tqdm import tqdm
from concurrent.futures import ThreadPoolExecutor, as_completed

# 输入路径和输出路径
input_dir = "/mnt/raid/VCD_dataset/PSF_learning/clean_g/"
output_dir = "/mnt/raid/VCD_dataset/PSF_learning/tiff_output/"

# 创建输出目录（如果不存在）
os.makedirs(output_dir, exist_ok=True)

# 获取所有 output 文件夹
output_folders = [f"ouput_{i + 1}" for i in range(27)]


def process_folder(folder_path):
    """读取并处理单个文件夹中的所有 .tif 文件"""
    tif_files = sorted([f for f in os.listdir(folder_path) if f.endswith(".tif")])
    if len(tif_files) != 4000:
        print(f"警告: {folder_path} 中 tif 文件数量不是 4000。实际数量: {len(tif_files)}，跳过。")
        return None

    tif_stack = []
    for tif_file in tif_files:
        tif_path = os.path.join(folder_path, tif_file)
        img = np.array(Image.open(tif_path))  # 读取 tif 文件
        if img.shape != (600, 600):
            print(f"警告: {tif_file} 尺寸不是 (600, 600)，跳过此文件。")
            continue
        tif_stack.append(img)

    return np.stack(tif_stack, axis=0)  # (4000, 600, 600)


# 使用多线程处理所有文件夹
print("开始多线程读取和处理 tif 文件...")
stacked_tifs = []
with ThreadPoolExecutor(max_workers=8) as executor:  # 根据系统资源设置合适的线程数
    futures = {executor.submit(process_folder, os.path.join(input_dir, folder)): folder for folder in output_folders}

    for future in tqdm(as_completed(futures), total=len(futures), desc="Processing Folders"):
        result = future.result()
        if result is not None:
            stacked_tifs.append(result)

# 将所有文件堆叠成 (4000, 27, 600, 600)
if len(stacked_tifs) == 27:
    print("堆叠所有文件...")
    final_stack = np.stack(stacked_tifs, axis=1)  # (4000, 27, 600, 600)

    # 按顺序保存到输出目录
    print("开始保存文件...")
    for i in tqdm(range(4000), desc="Saving Files"):
        output_file = os.path.join(output_dir, f"stacked_{i + 1:04d}.tif")
        tiff.imwrite(output_file, final_stack[i])
else:
    print("处理失败：某些文件夹未正确处理，检查警告信息。")

print("处理完成！所有文件已保存到输出目录。")
