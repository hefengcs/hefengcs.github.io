import os
import numpy as np
import tifffile as tiff

# 更新输入目录和输出路径
input_dir = '/mnt/raid/VCD_dataset/PSF_learning/PSF_idea/'
output_path = '/mnt/raid/VCD_dataset/PSF_learning/PSF_idea/combined_PSF.tif'

# 初始化变量存储加和结果
combined_psf = None

# 遍历所有文件并进行加和
for i in range(1, 28):  # 从1到27
    input_path = os.path.join(input_dir, f'PSF_{i}.tif')

    # 检查输入文件是否存在
    if not os.path.exists(input_path):
        print(f"文件 {input_path} 不存在，跳过...")
        continue

    # 读取PSF文件
    psf_data = tiff.imread(input_path)

    # 如果是第一个文件，初始化combined_psf的形状
    if combined_psf is None:
        combined_psf = np.zeros_like(psf_data, dtype=np.float32)

    # 累加PSF数据
    combined_psf += psf_data
    print(f"已处理: {input_path}")

# 保存加和后的PSF
tiff.imwrite(output_path, combined_psf)
print(f"加和结果已保存至: {output_path}")
