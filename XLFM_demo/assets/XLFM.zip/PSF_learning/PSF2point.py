import os
import numpy as np
import tifffile as tiff

# 更新输入和输出目录路径
input_dir = '/mnt/raid/VCD_dataset/PSF_learning/PSF/'
output_dir = '/mnt/raid/VCD_dataset/PSF_learning/PSF_idea/'

# 确保输出目录存在
os.makedirs(output_dir, exist_ok=True)

# 定义处理函数
def process_psf(psf_data):
    processed_psf = np.zeros_like(psf_data, dtype=np.float32)
    for z in range(psf_data.shape[0]):
        layer = psf_data[z]
        max_position = np.unravel_index(np.argmax(layer), layer.shape)
        processed_psf[z, max_position[0], max_position[1]] = 1
    return processed_psf

# 批量处理文件
for i in range(1, 28):  # 从1到27
    input_path = os.path.join(input_dir, f'PSF_{i}.tif')
    output_path = os.path.join(output_dir, f'PSF_{i}.tif')

    # 检查输入文件是否存在
    if not os.path.exists(input_path):
        print(f"文件 {input_path} 不存在，跳过...")
        continue

    # 读取原始PSF文件
    psf_data = tiff.imread(input_path)

    # 处理数据
    processed_psf = process_psf(psf_data)

    # 保存处理后的PSF
    tiff.imwrite(output_path, processed_psf)
    print(f"处理完成: {input_path} -> {output_path}")
